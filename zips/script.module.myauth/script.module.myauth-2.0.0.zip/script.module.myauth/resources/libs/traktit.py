import xbmc
import xbmcgui

import os
import time
import xbmcvfs
from xml.etree import ElementTree

from resources.libs.common.config import CONFIG
from resources.libs.common import logging
from resources.libs.common import tools

ORDER = ['seren', 'ezra', 'fen', 'pov', 'umbrella', 'ghost', 'unleashed', 'chains', 'moria', 'base19', 'twisted', 'md', 'asgard', 'metv', 'homelander', 'genocide', 'shazam', 'thepromise', 'thecrew', 'nightwing', 'alvin', 'scrubs', 'tmdbhelper', 'myact', 'myacct', 'trakt',]

TRAKTID = {
   'seren': {
        'name'     : 'Seren',
        'plugin'   : 'plugin.video.seren',
        'saved'    : 'seren',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.seren'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.seren/resources/images', 'ico-seren-3.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.seren/resources/images', 'fanart-seren-3.png'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'seren_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.seren', 'settings.xml'),
        'default'  : 'trakt.username',
        'data'     : ['trakt.auth', 'trakt.clientid', 'trakt.refresh', 'trakt.secret', 'trakt.username', 'trakt.expires'],
        'activate' : 'Addon.OpenSettings(plugin.video.seren)'},
    'ezra': {
        'name'     : 'Ezra',
        'plugin'   : 'plugin.video.ezra',
        'saved'    : 'ezra',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.ezra'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.ezra', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.ezra', 'fanart.png'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'ezra_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.ezra', 'settings.xml'),
        'default'  : 'trakt_user',
        'data'     : ['trakt.expires', 'trakt.token', 'trakt_user'],
        'activate' : 'Addon.OpenSettings(plugin.video.ezra)'},
    'fen': {
        'name'     : 'Fen',
        'plugin'   : 'plugin.video.fen',
        'saved'    : 'fen',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.fen'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.fen/resources/media/', 'fen_icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.fen/resources/media/', 'fen_fanart.png'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'fen_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.fen', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.refresh', 'trakt.expires', 'trakt.token', 'trakt.user'],
        'activate' : 'Addon.OpenSettings(plugin.video.fen)'},
    'pov': {
        'name'     : 'POV',
        'plugin'   : 'plugin.video.pov',
        'saved'    : 'pov',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.pov'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.pov', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.pov', 'fanart.png'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'pov_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.pov', 'settings.xml'),
        'default'  : 'trakt_user',
        'data'     : ['trakt.refresh', 'trakt.expires', 'trakt.token', 'trakt_user'],
        'activate' : 'Addon.OpenSettings(plugin.video.pov)'},
    'umbrella': {
        'name'     : 'Umbrella',
        'plugin'   : 'plugin.video.umbrella',
        'saved'    : 'umbrella',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.umbrella'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.umbrella', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.umbrella', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'umbrella_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.umbrella', 'settings.xml'),
        'default'  : 'trakt.user.name',
        'data'     : ['trakt.clientid', 'trakt.clientsecret', 'trakt.user.token', 'trakt.user.name', 'trakt.token.expires', 'trakt.refreshtoken', 'trakt.isauthed'],
        'activate' : 'Addon.OpenSettings(plugin.video.umbrella)'},
    'ghost': {
        'name'     : 'Ghost',
        'plugin'   : 'plugin.video.ghost',
        'saved'    : 'ghost',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.ghost'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.ghost', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.ghost', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'ghost_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.ghost', 'settings.xml'),
        'default'  : 'trakt_expires_at',
        'data'     : ['trakt_expires_at', 'trakt_refresh_token', 'trakt_access_token'],
        'activate' : 'Addon.OpenSettings(plugin.video.ghost)'},
    'unleashed': {
        'name'     : 'Unleashed',
        'plugin'   : 'plugin.video.unleashed',
        'saved'    : 'unleashed',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.unleashed'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.unleashed', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.unleashed', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'unleashed_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.unleashed', 'settings.xml'),
        'default'  : 'trakt_expires_at',
        'data'     : ['trakt_expires_at', 'trakt_refresh_token', 'trakt_access_token'],
        'activate' : 'Addon.OpenSettings(plugin.video.unleashed)'},
    'chains': {
        'name'     : 'Chains Reaction',
        'plugin'   : 'plugin.video.thechains',
        'saved'    : 'chains',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.thechains'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.thechains', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.thechains', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'chains_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.thechains', 'settings.xml'),
        'default'  : 'trakt_expires_at',
        'data'     : ['trakt_expires_at', 'trakt_refresh_token', 'trakt_access_token'],
        'activate' : 'Addon.OpenSettings(plugin.video.thechains)'},
   'moria': {
        'name'     : 'Moria',
        'plugin'   : 'plugin.video.moria',
        'saved'    : 'moria',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.moria'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.moria', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.moria', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'moria_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.moria', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.authed', 'trakt.user', 'trakt.token' 'trakt.refresh', 'trakt.client_id', 'trakt.client_secret'],
        'activate' : 'Addon.OpenSettings(plugin.video.moria)'},
    'base19': {
        'name'     : 'Base 19',
        'plugin'   : 'plugin.video.base19',
        'saved'    : 'base19',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.base19'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.base19', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.base19', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'base19_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.base19', 'settings.xml'),
        'default'  : 'trakt_expires_at',
        'data'     : ['trakt_expires_at', 'trakt_refresh_token', 'trakt_access_token'],
        'activate' : 'Addon.OpenSettings(plugin.video.base19)'},
    'twisted': {
        'name'     : 'Twisted',
        'plugin'   : 'plugin.video.twisted',
        'saved'    : 'twisted',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.twisted'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.twisted', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.twisted', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'twisted_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.twisted', 'settings.xml'),
        'default'  : 'trakt_expires_at',
        'data'     : ['trakt_expires_at', 'trakt_refresh_token', 'trakt_access_token'],
        'activate' : 'Addon.OpenSettings(plugin.video.twisted)'},
    'md': {
        'name'     : 'Magic Dragon',
        'plugin'   : 'plugin.video.magicdragon',
        'saved'    : 'md',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.magicdragon'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.magicdragon', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.magicdragon', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'md_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.magicdragon', 'settings.xml'),
        'default'  : 'trakt_expires_at',
        'data'     : ['trakt_expires_at', 'trakt_refresh_token', 'trakt_access_token'],
        'activate' : 'Addon.OpenSettings(plugin.video.magicdragon)'},
    'asgard': {
        'name'     : 'Asgard',
        'plugin'   : 'plugin.video.asgard',
        'saved'    : 'asgard',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.asgard'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.asgard', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.asgard', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'asgard_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.asgard', 'settings.xml'),
        'default'  : 'trakt_expires_at',
        'data'     : ['trakt_expires_at', 'trakt_refresh_token', 'trakt_access_token'],
        'activate' : 'Addon.OpenSettings(plugin.video.asgard)'},
    'metv': {
        'name'     : 'M.E.T.V',
        'plugin'   : 'plugin.video.metv19',
        'saved'    : 'metv',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.metv19'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.metv19', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.metv19', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'asgard_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.metv19', 'settings.xml'),
        'default'  : 'trakt_expires_at',
        'data'     : ['trakt_expires_at', 'trakt_refresh_token', 'trakt_access_token'],
        'activate' : 'Addon.OpenSettings(plugin.video.metv19)'},
   'homelander': {
        'name'     : 'Homelander',
        'plugin'   : 'plugin.video.homelander',
        'saved'    : 'homelander',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.homelander'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.homelander', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.homelander', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'homelander_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.homelander', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.authed', 'trakt.user', 'trakt.token' 'trakt.refresh', 'trakt.client_id', 'trakt.client_secret'],
        'activate' : 'Addon.OpenSettings(plugin.video.homelander)'},
   'genocide': {
        'name'     : 'Chains Genocide',
        'plugin'   : 'plugin.video.chainsgenocide',
        'saved'    : 'chainsgenocide',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.chainsgenocide'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.chainsgenocide', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.chainsgenocide', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'chainsgenocide_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.chainsgenocide', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.authed', 'trakt.user', 'trakt.token' 'trakt.refresh', 'trakt.client_id', 'trakt.client_secret'],
        'activate' : 'Addon.OpenSettings(plugin.video.chainsgenocide)'},
   'shazam': {
        'name'     : 'Shazam',
        'plugin'   : 'plugin.video.shazam',
        'saved'    : 'shazam',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.shazam'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.shazam', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.shazam', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'shazam_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.shazam', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.authed', 'trakt.user', 'trakt.token' 'trakt.refresh', 'trakt.client_id', 'trakt.client_secret'],
        'activate' : 'Addon.OpenSettings(plugin.video.shazam)'},
   'thepromise': {
        'name'     : 'The Promise',
        'plugin'   : 'plugin.video.thepromise',
        'saved'    : 'thepromise',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.thepromise'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.thepromise', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.thepromise', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'thepromise_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.thepromise', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.authed', 'trakt.user', 'trakt.token' 'trakt.refresh', 'trakt.client_id', 'trakt.client_secret'],
        'activate' : 'Addon.OpenSettings(plugin.video.thepromise)'},
   'thecrew': {
        'name'     : 'The Crew',
        'plugin'   : 'plugin.video.thecrew',
        'saved'    : 'thecrew',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.thecrew'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.thecrew', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.thecrew', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'thecrew_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.thecrew', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.refresh', 'trakt.token', 'trakt.user'],
        'activate' : 'Addon.OpenSettings(plugin.video.thecrew)'},
   'nightwing': {
        'name'     : 'Nightwing',
        'plugin'   : 'plugin.video.nightwing',
        'saved'    : 'nightwing',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.nightwing'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.nightwing', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.nightwing', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'nightwing_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.nightwing', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.client_id', 'trakt.client_secret', 'trakt.refresh', 'trakt.token', 'trakt.user'],
        'activate' : 'Addon.OpenSettings(plugin.video.nightwing)'},
   'alvin': {
        'name'     : 'Alvin',
        'plugin'   : 'plugin.video.alvin',
        'saved'    : 'alvin',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.alvin'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.alvin', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.alvin', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'alvin_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.alvin', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.client_id', 'trakt.client_secret', 'trakt.refresh', 'trakt.token', 'trakt.user'],
        'activate' : 'Addon.OpenSettings(plugin.video.alvin)'},
   'scrubs': {
        'name'     : 'Scrubs V2',
        'plugin'   : 'plugin.video.scrubsv2',
        'saved'    : 'scrubsv2',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.scrubsv2'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.scrubsv2/resources/images', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.scrubsv2/resources/images', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'scrubsv2_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.scrubsv2', 'settings.xml'),
        'default'  : 'trakt.user',
        'data'     : ['trakt.refresh', 'trakt.token', 'trakt.user'],
        'activate' : 'Addon.OpenSettings(plugin.video.scrubsv2)'},
   'tmdbhelper': {
        'name'     : 'TMDB Helper',
        'plugin'   : 'plugin.video.themoviedb.helper',
        'saved'    : 'tmdbhelper',
        'path'     : os.path.join(CONFIG.ADDONS, 'plugin.video.themoviedb.helper'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'plugin.video.themoviedb.helper', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'plugin.video.themoviedb.helper', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'tmdbhelper_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'plugin.video.themoviedb.helper', 'settings.xml'),
        'default'  : 'trakt_token',
        'data'     : ['trakt_token'],
        'activate' : 'Addon.OpenSettings(plugin.video.themoviedb.helper)'},
   'myact': {
        'name'     : 'My Accounts',
        'plugin'   : 'script.module.myaccounts',
        'saved'    : 'myact',
        'path'     : os.path.join(CONFIG.ADDONS, 'script.module.myaccounts'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'script.module.myaccounts', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'script.module.myaccounts', 'fanart.png'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'myact_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'script.module.myaccounts', 'settings.xml'),
        'default'  : 'trakt.username',
        'data'     : ['trakt.client.id', 'trakt.client.secret', 'trakt.expires', 'trakt.refresh', 'trakt.token', 'trakt.username'],
        'activate' : 'Addon.OpenSettings(script.module.myaccounts)'},
   'myacct': {
        'name'     : 'Account Manager',
        'plugin'   : 'script.module.myaccts',
        'saved'    : 'myacct',
        'path'     : os.path.join(CONFIG.ADDONS, 'script.module.myaccts'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'script.module.myaccts', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'script.module.myaccts', 'fanart.png'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'myacct_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'script.module.myaccts', 'settings.xml'),
        'default'  : 'trakt.username',
        'data'     : ['trakt.client.id', 'trakt.client.secret', 'trakt.expires', 'trakt.refresh', 'trakt.token', 'trakt.username'],
        'activate' : 'Addon.OpenSettings(script.module.myaccts)'},
   'trakt': {
        'name'     : 'Trakt Add-on',
        'plugin'   : 'script.trakt',
        'saved'    : 'trakt',
        'path'     : os.path.join(CONFIG.ADDONS, 'script.trakt'),
        'icon'     : os.path.join(CONFIG.ADDONS, 'script.trakt', 'icon.png'),
        'fanart'   : os.path.join(CONFIG.ADDONS, 'script.trakt', 'fanart.jpg'),
        'file'     : os.path.join(CONFIG.TRAKTFOLD, 'trakt_trakt'),
        'settings' : os.path.join(CONFIG.ADDON_DATA, 'script.trakt', 'settings.xml'),
        'default'  : 'user',
        'data'     : ['authorization', 'user'],
        'activate' : 'Addon.OpenSettings(script.trakt)'},
}


def trakt_user(who):
    user = None
    if TRAKTID[who]:
        if os.path.exists(TRAKTID[who]['path']):
            try:
                add = tools.get_addon_by_id(TRAKTID[who]['plugin'])
                user = add.getSetting(TRAKTID[who]['default'])
            except:
                return None
    return user


def trakt_it(do, who):
    if not os.path.exists(CONFIG.ADDON_DATA):
        os.makedirs(CONFIG.ADDON_DATA)
    if not os.path.exists(CONFIG.TRAKTFOLD):
        os.makedirs(CONFIG.TRAKTFOLD)
    if who == 'all':
        for log in ORDER:
            if os.path.exists(TRAKTID[log]['path']):
                try:
                    addonid = tools.get_addon_by_id(TRAKTID[log]['plugin'])
                    default = TRAKTID[log]['default']
                    user = addonid.getSetting(default)
                    
                    update_trakt(do, log)
                except:
                    pass
            else:
                logging.log('[Trakt Data] {0}({1}) is not installed'.format(TRAKTID[log]['name'], TRAKTID[log]['plugin']), level=xbmc.LOGERROR)
        CONFIG.set_setting('traktnextsave', tools.get_date(days=3, formatted=True))
    else:
        if TRAKTID[who]:
            if os.path.exists(TRAKTID[who]['path']):
                update_trakt(do, who)
        else:
            logging.log('[Trakt Data] Invalid Entry: {0}'.format(who), level=xbmc.LOGERROR)

def trakt_it_revoke(do, who):
    if not os.path.exists(CONFIG.ADDON_DATA):
        os.makedirs(CONFIG.ADDON_DATA)
    if not os.path.exists(CONFIG.TRAKTFOLD):
        os.makedirs(CONFIG.TRAKTFOLD)
    if who == 'all':
        for log in ORDER:
            if os.path.exists(TRAKTID[log]['path']):
                try:
                    addonid = tools.get_addon_by_id(TRAKTID[log]['plugin'])
                    default = TRAKTID[log]['default']
                    user = addonid.getSetting(default)
                    
                    update_trakt(do, log)
                except:
                    pass
            else:
                logging.log('[Trakt Data] {0}({1}) is not installed'.format(TRAKTID[log]['name'], TRAKTID[log]['plugin']), level=xbmc.LOGERROR)
        CONFIG.set_setting('traktnextsave', tools.get_date(days=3, formatted=True))
    else:
        if TRAKTID[who]:
            if os.path.exists(TRAKTID[who]['path']):
                update_trakt(do, who)
        else:
            logging.log('[Trakt Data] Invalid Entry: {0}'.format(who), level=xbmc.LOGERROR)
    revoke_trakt()

def trakt_it_restore(do, who):
    if not os.path.exists(CONFIG.ADDON_DATA):
        os.makedirs(CONFIG.ADDON_DATA)
    if not os.path.exists(CONFIG.TRAKTFOLD):
        os.makedirs(CONFIG.TRAKTFOLD)
    if who == 'all':
        for log in ORDER:
            if os.path.exists(TRAKTID[log]['path']):
                try:
                    addonid = tools.get_addon_by_id(TRAKTID[log]['plugin'])
                    default = TRAKTID[log]['default']
                    user = addonid.getSetting(default)
                    
                    update_trakt(do, log)
                except:
                    pass
            else:
                logging.log('[Trakt Data] {0}({1}) is not installed'.format(TRAKTID[log]['name'], TRAKTID[log]['plugin']), level=xbmc.LOGERROR)
        CONFIG.set_setting('traktnextsave', tools.get_date(days=3, formatted=True))
    else:
        if TRAKTID[who]:
            if os.path.exists(TRAKTID[who]['path']):
                update_trakt(do, who)
        else:
            logging.log('[Trakt Data] Invalid Entry: {0}'.format(who), level=xbmc.LOGERROR)
    restore_trakt()
    
def clear_saved(who, over=False):
    if who == 'all':
        for trakt in TRAKTID:
            clear_saved(trakt,  True)
    elif TRAKTID[who]:
        file = TRAKTID[who]['file']
        if os.path.exists(file):
            os.remove(file)
            logging.log_notify("[COLOR {0}]{1}[/COLOR]".format(CONFIG.COLOR1, TRAKTID[who]['name']),
                               '[COLOR {0}]Trakt Data: Removed![/COLOR]'.format(CONFIG.COLOR2),
                               2000,
                               TRAKTID[who]['icon'])
        CONFIG.set_setting(TRAKTID[who]['saved'], '')
    if not over:
        xbmc.executebuiltin('Container.Refresh()')


def update_trakt(do, who):
    file = TRAKTID[who]['file']
    settings = TRAKTID[who]['settings']
    data = TRAKTID[who]['data']
    addonid = tools.get_addon_by_id(TRAKTID[who]['plugin'])
    saved = TRAKTID[who]['saved']
    default = TRAKTID[who]['default']
    user = addonid.getSetting(default)
    suser = CONFIG.get_setting(saved)
    name = TRAKTID[who]['name']
    icon = TRAKTID[who]['icon']

    if do == 'update':
        if not user == '':
            try:
                root = ElementTree.Element(saved)
                
                for setting in data:
                    trakt = ElementTree.SubElement(root, 'trakt')
                    id = ElementTree.SubElement(trakt, 'id')
                    id.text = setting
                    value = ElementTree.SubElement(trakt, 'value')
                    value.text = addonid.getSetting(setting)
                  
                tree = ElementTree.ElementTree(root)
                tree.write(file)
                
                user = addonid.getSetting(default)
                CONFIG.set_setting(saved, user)
                logging.log('Trakt Data Saved for {0}'.format(name), level=xbmc.LOGINFO)
            except Exception as e:
                logging.log("[Trakt Data] Unable to Update {0} ({1})".format(who, str(e)), level=xbmc.LOGERROR)
        else:
            logging.log('Trakt Data Not Registered for {0}'.format(name))
    elif do == 'restore':
        if os.path.exists(file):
            tree = ElementTree.parse(file)
            root = tree.getroot()
            
            try:
                for setting in root.findall('trakt'):
                    id = setting.find('id').text
                    value = setting.find('value').text
                    addonid.setSetting(id, value)
                
                user = addonid.getSetting(default)
                CONFIG.set_setting(saved, user)
                logging.log('Trakt Data Restored for {0}'.format(name), level=xbmc.LOGINFO)
            except Exception as e:
                logging.log("[Trakt Data] Unable to Restore {0} ({1})".format(who, str(e)), level=xbmc.LOGERROR)
        else:
            logging.log('Trakt Data Not Found for {0}'.format(name))
    elif do == 'clearaddon':
        logging.log('{0} SETTINGS: {1}'.format(name, settings))
        if os.path.exists(settings):
            try:
                tree = ElementTree.parse(settings)
                root = tree.getroot()
                
                for setting in root.findall('setting'):
                    if setting.attrib['id'] in data:
                        logging.log('Removing Setting: {0}'.format(setting.attrib))
                        root.remove(setting)
                            
                tree.write(settings)
                
                logging.log_notify("[COLOR {0}]{1}[/COLOR]".format(CONFIG.COLOR1, name),
                                   '[COLOR {0}]Addon Data: Cleared![/COLOR]'.format(CONFIG.COLOR2),
                                   2000,
                                   icon)
            except Exception as e:
                logging.log("[Trakt Data] Unable to Clear Addon {0} ({1})".format(who, str(e)), level=xbmc.LOGERROR)
    xbmc.executebuiltin('Container.Refresh()')


def auto_update(who):
    if who == 'all':
        for log in TRAKTID:
            if os.path.exists(TRAKTID[log]['path']):
                auto_update(log)
    elif TRAKTID[who]:
        if os.path.exists(TRAKTID[who]['path']):
            u = trakt_user(who)
            su = CONFIG.get_setting(TRAKTID[who]['saved'])
            n = TRAKTID[who]['name']
            if not u or u == '':
                return
            elif su == '':
                trakt_it('update', who)
            elif not u == su:
                dialog = xbmcgui.Dialog()

                if dialog.yesno(CONFIG.ADDONTITLE,
                                    "Would you like to save the [COLOR {0}]Trakt Data[/COLOR] for [COLOR {1}]{2}[/COLOR]?".format(CONFIG.COLOR2, CONFIG.COLOR1, n),
                                    "Addon: [COLOR springgreen][B]{0}[/B][/COLOR]".format(u),
                                    "Saved:[/COLOR] [COLOR red][B]{0}[/B][/COLOR]".format(su) if not su == '' else 'Saved:[/COLOR] [COLOR red][B]None[/B][/COLOR]',
                                    yeslabel="[B][COLOR springgreen]Save Data[/COLOR][/B]",
                                    nolabel="[B][COLOR red]No Cancel[/COLOR][/B]"):
                    trakt_it('update', who)
            else:
                trakt_it('update', who)


def import_list(who):
    if who == 'all':
        for log in TRAKTID:
            if os.path.exists(TRAKTID[log]['file']):
                import_list(log)
    elif TRAKTID[who]:
        if os.path.exists(TRAKTID[who]['file']):
            file = TRAKTID[who]['file']
            addonid = tools.get_addon_by_id(TRAKTID[who]['plugin'])
            saved = TRAKTID[who]['saved']
            default = TRAKTID[who]['default']
            suser = CONFIG.get_setting(saved)
            name = TRAKTID[who]['name']
            
            tree = ElementTree.parse(file)
            root = tree.getroot()
            
            for setting in root.findall('trakt'):
                id = setting.find('id').text
                value = setting.find('value').text
            
                addonid.setSetting(id, value)

            logging.log_notify("[COLOR {0}]{1}[/COLOR]".format(CONFIG.COLOR1, name),
                       '[COLOR {0}]Trakt Data: Imported![/COLOR]'.format(CONFIG.COLOR2))


def open_settings_trakt(who):
    addonid = tools.get_addon_by_id(TRAKTID[who]['plugin'])
    addonid.openSettings()

def revoke_trakt(): #Restore default API keys to all add-ons

    addon_seren = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/')

    if xbmcvfs.exists(addon_seren):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/resources/lib/indexers/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'0c9a30819e4af6ffaf3b954cbeae9b54499088513863c03c02911de00ac2de79'
        new_client = data.replace(f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'bf02417f27b514cee6a8d135f2ddc261a15eecfb6ed6289c36239826dcdd1842'
        new_secret = data.replace(f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()
        
    addon_fen = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/')

    if xbmcvfs.exists(addon_fen):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/resources/lib/apis/trakt_api.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'645b0f46df29d27e63c4a8d5fff158edd0bef0a6a5d32fc12c1b82388be351af'
        new_client = data.replace(f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'422a282ef5fe4b5c47bc60425c009ac3047ebd10a7f6af790303875419f18f98'
        new_secret = data.replace(f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_pov = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/')

    if xbmcvfs.exists(addon_pov):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/resources/lib/apis/trakt_api.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'd4161a7a106424551add171e5470112e4afdaf2438e6ef2fe0548edc75924868'
        new_client = data.replace(f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'b5fcd7cb5d9bb963784d11bbf8535bc0d25d46225016191eb48e50792d2155c0'
        new_secret = data.replace(f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_umb = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/')

    if xbmcvfs.exists(addon_umb):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'87e3f055fc4d8fcfd96e61a47463327ca877c51e8597b448e132611c5a677b13'
        new_client = data.replace(f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()
        
        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'4a1957a52d5feb98fafde53193e51f692fa9bdcd0cc13cf44a5e39975539edf0'
        new_secret = data.replace(f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_home = xbmcvfs.translatePath('special://home/addons/plugin.video.homelander/')


    if xbmcvfs.exists(addon_home):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.homelander/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'api_keys.trakt_client_id'
        new_client = data.replace(f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'",client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'api_keys.trakt_secret'
        new_secret = data.replace(f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'",secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    if xbmcvfs.exists(addon_genocide):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.chainsgenocide/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'api_keys.trakt_client_id'
        new_client = data.replace(f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'",client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'api_keys.trakt_secret'
        new_secret = data.replace(f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'",secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()
        
    addon_crew = xbmcvfs.translatePath('special://home/addons/plugin.video.thecrew/')

    if xbmcvfs.exists(addon_crew):

        client_keys = xbmcvfs.translatePath('special://home/addons/script.module.thecrew/lib/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'482f9db52ee2611099ce3aa1abf9b0f7ed893c6d3c6b5face95164eac7b01f71'
        new_client = data.replace(f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'80a2729728b53ba1cc38137b22f21f34d590edd35454466c4b8920956513d967'
        new_secret = data.replace(f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_shazam = xbmcvfs.translatePath('special://home/addons/plugin.video.shazam/')

    if xbmcvfs.exists(addon_shazam):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.shazam/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'api_keys.trakt_client_id'
        new_client = data.replace(f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'",client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'api_keys.trakt_secret'
        new_secret = data.replace(f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'",secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_night = xbmcvfs.translatePath('special://home/addons/plugin.video.nightwing/')

    if xbmcvfs.exists(addon_night):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.nightwing/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'base64.b64decode("MjFiODhkNGRjZDU4ZjVlY2EzOTEyOGE3MzZkMjIxNmRhNTZiNTIxMTQ4MDUyNThjNGU5ZjlhNjNkOTgwMDcyMg==")'
        new_client = data.replace(f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'",client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'base64.b64decode("MjM4OGIzMDdkZDFiYTU0NGQ2ZmEwZTFmNTcxNDczNWJkNTIwYzhmZTM4ZGYyMTEyZDg4ODg1MmJhODE1YWRlOQ==")'
        new_secret = data.replace(f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'",secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_promise = xbmcvfs.translatePath('special://home/addons/plugin.video.thepromise/')

    if xbmcvfs.exists(addon_promise):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.thepromise/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'api_keys.trakt_client_id'
        new_client = data.replace(f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'",client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'api_keys.trakt_secret'
        new_secret = data.replace(f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'",secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_scrubs = xbmcvfs.translatePath('special://home/addons/plugin.video.scrubsv2/')

    if xbmcvfs.exists(addon_scrubs):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.scrubsv2/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'63c53edc299b7a05cc6ea2272e8a84e13aade067c18a794362ab9a4a84eafb16'
        new_client = data.replace(f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'9163ebda9d33acd06c74d017e861404b7212ee34675e09e73365d7536b84eab6'
        new_secret = data.replace(f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_alvin = xbmcvfs.translatePath('special://home/addons/plugin.video.alvin/')
    
    if xbmcvfs.exists(addon_alvin):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.alvin/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'api_keys.trakt_client_id'
        new_client = data.replace(f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'",client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'api_keys.trakt_secret'
        new_secret = data.replace(f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'",secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()
        
    addon_shadow = xbmcvfs.translatePath('special://home/addons/plugin.video.shadow/')
    
    if xbmcvfs.exists(addon_shadow):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.shadow/resources/modules/general.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'8ed545c0b7f92cc26d1ecd6326995c6cf0053bd7596a98e962a472bee63274e6'
        new_client = data.replace(f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'1ec4f37e5743e3086abace0c83444c25d9b655d1d77b793806b2c8205a510426'
        new_secret = data.replace(f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_ghost = xbmcvfs.translatePath('special://home/addons/plugin.video.ghost/')
    
    if xbmcvfs.exists(addon_ghost):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.ghost/resources/modules/general.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'a4e716b4b22b62e59b9e09454435c8710b650b3143dcce553d252b6a66ba60c8'
        new_client = data.replace(f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'c6d9aba72214a1ca3c6d45d0351e59f21bbe43df9bbac7c5b740089379f8c5cd'
        new_secret = data.replace(f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()
        
    addon_unleashed = xbmcvfs.translatePath('special://home/addons/plugin.video.unleashed/')
    
    if xbmcvfs.exists(addon_unleashed):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.unleashed/resources/modules/general.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'19849909a0f8c9dc632bc5f5c7ccafd19f3e452e2e44fee05b83fd5dc1e77675'
        new_client = data.replace(f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'122b7a79437dcf4b657d3af9e92f2d9ff8939ade532e03bc81bfb5ce798b04bf'
        new_secret = data.replace(f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_chains = xbmcvfs.translatePath('special://home/addons/plugin.video.thechains/')
    
    if xbmcvfs.exists(addon_chains):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.thechains/resources/modules/general.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'19849909a0f8c9dc632bc5f5c7ccafd19f3e452e2e44fee05b83fd5dc1e77675'
        new_client = data.replace(f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'122b7a79437dcf4b657d3af9e92f2d9ff8939ade532e03bc81bfb5ce798b04bf'
        new_secret = data.replace(f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_md = xbmcvfs.translatePath('special://home/addons/plugin.video.magicdragon/')
    
    if xbmcvfs.exists(addon_md):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.magicdragon/resources/modules/general.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'8ed545c0b7f92cc26d1ecd6326995c6cf0053bd7596a98e962a472bee63274e6'
        new_client = data.replace(f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'122b7a79437dcf4b657d3af9e92f2d9ff8939ade532e03bc81bfb5ce798b04bf'
        new_secret = data.replace(f'1ec4f37e5743e3086abace0c83444c25d9b655d1d77b793806b2c8205a510426',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_asgard = xbmcvfs.translatePath('special://home/addons/plugin.video.asgard/')
    
    if xbmcvfs.exists(addon_asgard):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.asgard/resources/modules/general.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'54de56f7b90a4cf7227fd70ecf703c6c043ec135c56ad10c9bb90c539bf2749f'
        new_client = data.replace(f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'a43aa6bd62eb5afd37ede4a625457fc903f1961b8384178986bf76eebfcd5999'
        new_secret = data.replace(f'1ec4f37e5743e3086abace0c83444c25d9b655d1d77b793806b2c8205a510426',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()
     
    addon_myaccounts = xbmcvfs.translatePath('special://home/addons/script.module.myaccounts/')

    if xbmcvfs.exists(addon_myaccounts):

        client_keys = xbmcvfs.translatePath('special://home/addons/script.module.myaccounts/lib/myaccounts/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'e3a8d1c673dfecb7f669b23ecbf77c75fcfd24d3e8c3dbc7f79ed995262fa1db'
        new_client = data.replace(f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'73bee6aeee29cb75db4d8771458a440017f7cfe842e85f457ed9d81f7910b349'
        new_secret = data.replace(f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()
        
    addon_tmdbh = xbmcvfs.translatePath('special://home/addons/plugin.video.themoviedb.helper/')

    if xbmcvfs.exists(addon_tmdbh):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.themoviedb.helper/resources/tmdbhelper/lib/api/api_keys/trakt.py')
                
        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'e6fde6173adf3c6af8fd1b0694b9b84d7c519cefc24482310e1de06c6abe5467'
        new_client = data.replace(f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'15119384341d9a61c751d8d515acbc0dd801001d4ebe85d3eef9885df80ee4d9'
        new_secret = data.replace(f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_trakt = xbmcvfs.translatePath('special://home/addons/script.trakt/')

    if xbmcvfs.exists(addon_trakt):

        client_keys = xbmcvfs.translatePath('special://home/addons/script.trakt/resources/lib/traktapi.py')
                
        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'd4161a7a106424551add171e5470112e4afdaf2438e6ef2fe0548edc75924868'
        new_client = data.replace(f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'b5fcd7cb5d9bb963784d11bbf8535bc0d25d46225016191eb48e50792d2155c0'
        new_secret = data.replace(f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()
   
def restore_trakt(): #Restore API Keys to all add-ons

    addon_seren = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/')

    if xbmcvfs.exists(addon_seren):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/resources/lib/indexers/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        new_client = data.replace(f'0c9a30819e4af6ffaf3b954cbeae9b54499088513863c03c02911de00ac2de79',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
        new_secret = data.replace(f'bf02417f27b514cee6a8d135f2ddc261a15eecfb6ed6289c36239826dcdd1842',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()
        
    addon_fen = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/')

    if xbmcvfs.exists(addon_fen):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/resources/lib/apis/trakt_api.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        new_client = data.replace(f'645b0f46df29d27e63c4a8d5fff158edd0bef0a6a5d32fc12c1b82388be351af',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
        new_secret = data.replace(f'422a282ef5fe4b5c47bc60425c009ac3047ebd10a7f6af790303875419f18f98',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_pov = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/')

    if xbmcvfs.exists(addon_pov):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/resources/lib/apis/trakt_api.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        new_client = data.replace(f'd4161a7a106424551add171e5470112e4afdaf2438e6ef2fe0548edc75924868',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
        new_secret = data.replace(f'b5fcd7cb5d9bb963784d11bbf8535bc0d25d46225016191eb48e50792d2155c0',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_umb = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/')

    if xbmcvfs.exists(addon_umb):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        new_client = data.replace(f'87e3f055fc4d8fcfd96e61a47463327ca877c51e8597b448e132611c5a677b13',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
        new_secret = data.replace(f'4a1957a52d5feb98fafde53193e51f692fa9bdcd0cc13cf44a5e39975539edf0',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_home = xbmcvfs.translatePath('special://home/addons/plugin.video.homelander/')

    if xbmcvfs.exists(addon_home):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.homelander/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
        new_client = data.replace(f'api_keys.trakt_client_id',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
        new_secret = data.replace(f'api_keys.trakt_secret',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_genocide = xbmcvfs.translatePath('special://home/addons/plugin.video.chainsgenocide/')

    if xbmcvfs.exists(addon_genocide):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.chainsgenocide/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
        new_client = data.replace(f'api_keys.trakt_client_id',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
        new_secret = data.replace(f'api_keys.trakt_secret',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()
        
    addon_crew = xbmcvfs.translatePath('special://home/addons/plugin.video.thecrew/')

    if xbmcvfs.exists(addon_crew):

        client_keys = xbmcvfs.translatePath('special://home/addons/script.module.thecrew/lib/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        new_client = data.replace(f'482f9db52ee2611099ce3aa1abf9b0f7ed893c6d3c6b5face95164eac7b01f71',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
        new_secret = data.replace(f'80a2729728b53ba1cc38137b22f21f34d590edd35454466c4b8920956513d967',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_shazam = xbmcvfs.translatePath('special://home/addons/plugin.video.shazam/')

    if xbmcvfs.exists(addon_shazam):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.shazam/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
        new_client = data.replace(f'api_keys.trakt_client_id',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
        new_secret = data.replace(f'api_keys.trakt_secret',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_night = xbmcvfs.translatePath('special://home/addons/plugin.video.nightwing/')

    if xbmcvfs.exists(addon_night):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.nightwing/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
        new_client = data.replace(f'base64.b64decode("MjFiODhkNGRjZDU4ZjVlY2EzOTEyOGE3MzZkMjIxNmRhNTZiNTIxMTQ4MDUyNThjNGU5ZjlhNjNkOTgwMDcyMg==")',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
        new_secret = data.replace(f'base64.b64decode("MjM4OGIzMDdkZDFiYTU0NGQ2ZmEwZTFmNTcxNDczNWJkNTIwYzhmZTM4ZGYyMTEyZDg4ODg1MmJhODE1YWRlOQ==")',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_promise = xbmcvfs.translatePath('special://home/addons/plugin.video.thepromise/')

    if xbmcvfs.exists(addon_promise):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.thepromise/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
        new_client = data.replace(f'api_keys.trakt_client_id',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
        new_secret = data.replace(f'api_keys.trakt_secret',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_scrubs = xbmcvfs.translatePath('special://home/addons/plugin.video.scrubsv2/')

    if xbmcvfs.exists(addon_scrubs):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.scrubsv2/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        new_client = data.replace(f'63c53edc299b7a05cc6ea2272e8a84e13aade067c18a794362ab9a4a84eafb16',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
        new_secret = data.replace(f'9163ebda9d33acd06c74d017e861404b7212ee34675e09e73365d7536b84eab6',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_alvin = xbmcvfs.translatePath('special://home/addons/plugin.video.alvin/')
    
    if xbmcvfs.exists(addon_alvin):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.alvin/resources/lib/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
        new_client = data.replace(f'api_keys.trakt_client_id,client')
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
        new_secret = data.replace(f'api_keys.trakt_secret',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_shadow = xbmcvfs.translatePath('special://home/addons/plugin.video.shadow/')
    
    if xbmcvfs.exists(addon_shadow):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.shadow/resources/modules/general.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        new_client = data.replace(f'8ed545c0b7f92cc26d1ecd6326995c6cf0053bd7596a98e962a472bee63274e6',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
        new_secret = data.replace(f'1ec4f37e5743e3086abace0c83444c25d9b655d1d77b793806b2c8205a510426',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_ghost = xbmcvfs.translatePath('special://home/addons/plugin.video.ghost/')
    
    if xbmcvfs.exists(addon_ghost):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.ghost/resources/modules/general.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        new_client = data.replace(f'a4e716b4b22b62e59b9e09454435c8710b650b3143dcce553d252b6a66ba60c8',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
        new_secret = data.replace(f'c6d9aba72214a1ca3c6d45d0351e59f21bbe43df9bbac7c5b740089379f8c5cd',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()
        
    addon_unleashed = xbmcvfs.translatePath('special://home/addons/plugin.video.unleashed/')
    
    if xbmcvfs.exists(addon_unleashed):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.unleashed/resources/modules/general.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        new_client = data.replace(f'19849909a0f8c9dc632bc5f5c7ccafd19f3e452e2e44fee05b83fd5dc1e77675',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
        new_secret = data.replace(f'122b7a79437dcf4b657d3af9e92f2d9ff8939ade532e03bc81bfb5ce798b04bf',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_chains = xbmcvfs.translatePath('special://home/addons/plugin.video.thechains/')
    
    if xbmcvfs.exists(addon_chains):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.thechains/resources/modules/general.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        new_client = data.replace(f'19849909a0f8c9dc632bc5f5c7ccafd19f3e452e2e44fee05b83fd5dc1e77675',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
        new_secret = data.replace(f'122b7a79437dcf4b657d3af9e92f2d9ff8939ade532e03bc81bfb5ce798b04bf',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_md = xbmcvfs.translatePath('special://home/addons/plugin.video.magicdragon/')
    
    if xbmcvfs.exists(addon_md):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.magicdragon/resources/modules/general.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        new_client = data.replace(f'8ed545c0b7f92cc26d1ecd6326995c6cf0053bd7596a98e962a472bee63274e6',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'1ec4f37e5743e3086abace0c83444c25d9b655d1d77b793806b2c8205a510426'
        new_secret = data.replace(f'122b7a79437dcf4b657d3af9e92f2d9ff8939ade532e03bc81bfb5ce798b04bf',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_asgard = xbmcvfs.translatePath('special://home/addons/plugin.video.asgard/')
    
    if xbmcvfs.exists(addon_asgard):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.asgard/resources/modules/general.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        new_client = data.replace(f'54de56f7b90a4cf7227fd70ecf703c6c043ec135c56ad10c9bb90c539bf2749f',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'1ec4f37e5743e3086abace0c83444c25d9b655d1d77b793806b2c8205a510426'
        new_secret = data.replace(f'a43aa6bd62eb5afd37ede4a625457fc903f1961b8384178986bf76eebfcd5999',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()
        
    addon_myaccounts = xbmcvfs.translatePath('special://home/addons/script.module.myaccounts/')

    if xbmcvfs.exists(addon_myaccounts):

        client_keys = xbmcvfs.translatePath('special://home/addons/script.module.myaccounts/lib/myaccounts/modules/trakt.py')

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        new_client = data.replace(f'e3a8d1c673dfecb7f669b23ecbf77c75fcfd24d3e8c3dbc7f79ed995262fa1db',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
        new_secret = data.replace(f'73bee6aeee29cb75db4d8771458a440017f7cfe842e85f457ed9d81f7910b349',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()
            
    addon_tmdbh = xbmcvfs.translatePath('special://home/addons/plugin.video.themoviedb.helper/')

    if xbmcvfs.exists(addon_tmdbh):

        client_keys = xbmcvfs.translatePath('special://home/addons/plugin.video.themoviedb.helper/resources/tmdbhelper/lib/api/api_keys/trakt.py')
                
        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        new_client = data.replace(f'e6fde6173adf3c6af8fd1b0694b9b84d7c519cefc24482310e1de06c6abe5467',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
        new_secret = data.replace(f'15119384341d9a61c751d8d515acbc0dd801001d4ebe85d3eef9885df80ee4d9',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()

    addon_trakt = xbmcvfs.translatePath('special://home/addons/script.trakt/')

    if xbmcvfs.exists(addon_trakt):

        client_keys = xbmcvfs.translatePath('special://home/addons/script.trakt/resources/lib/traktapi.py')
                
        f = open(client_keys,'r')
        data = f.read()
        f.close()
        client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        new_client = data.replace(f'd4161a7a106424551add171e5470112e4afdaf2438e6ef2fe0548edc75924868',client)
        f = open(client_keys,'w')
        f.write(new_client)
        f.close()

        f = open(client_keys,'r')
        data = f.read()
        f.close()
        secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
        new_secret = data.replace(f'b5fcd7cb5d9bb963784d11bbf8535bc0d25d46225016191eb48e50792d2155c0',secret)
        f = open(client_keys,'w')
        f.write(new_secret)
        f.close()
   
