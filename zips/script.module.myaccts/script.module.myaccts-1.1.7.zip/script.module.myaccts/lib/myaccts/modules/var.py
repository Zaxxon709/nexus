import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import os
addon_id = xbmcaddon.Addon().getAddonInfo('id')
addon = xbmcaddon.Addon(addon_id)
setting = addon.getSetting

#Account Mananger Check
check_myaccts_rd = xbmcaddon.Addon('script.module.myaccts').getSetting("realdebrid.token")
check_myaccts_pm = xbmcaddon.Addon('script.module.myaccts').getSetting("premiumize.token")
check_myaccts_ad = xbmcaddon.Addon('script.module.myaccts').getSetting("alldebrid.token")

#Add-on Paths
check_addon_seren = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/')
check_addon_fen = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/')
check_addon_ezra = xbmcvfs.translatePath('special://home/addons/plugin.video.ezra/')
check_addon_pov = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/')
check_addon_umb = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/')
check_addon_shadow = xbmcvfs.translatePath('special://home/addons/plugin.video.shadow/')
check_addon_ghost = xbmcvfs.translatePath('special://home/addons/plugin.video.ghost/')
check_addon_unleashed = xbmcvfs.translatePath('special://home/addons/plugin.video.unleashed/')
check_addon_chains = xbmcvfs.translatePath('special://home/addons/plugin.video.thechains/')
check_addon_md = xbmcvfs.translatePath('special://home/addons/plugin.video.magicdragon/')
check_addon_asgard = xbmcvfs.translatePath('special://home/addons/plugin.video.asgard/')
check_addon_moria = xbmcvfs.translatePath('special://home/addons/plugin.video.moria/')
check_addon_base = xbmcvfs.translatePath('special://home/addons/plugin.video.base19/')
check_addon_twisted = xbmcvfs.translatePath('special://home/addons/plugin.video.twisted/')
check_addon_metv = xbmcvfs.translatePath('special://home/addons/plugin.video.metv19/')
check_addon_premiumizer = xbmcvfs.translatePath('special://home/addons/plugin.video.premiumizerx/')
check_addon_realizer = xbmcvfs.translatePath('special://home/addons/plugin.video.realizerx/')
check_addon_rurl= xbmcvfs.translatePath('special://home/addons/script.module.resolveurl/')
check_addon_myaccounts = xbmcvfs.translatePath('special://home/addons/script.module.myaccounts/')

#Add-on settings.xml Paths
check_seren_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.seren/settings.xml')
check_fen_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.fen/settings.xml')
check_ezra_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.ezra/settings.xml')
check_pov_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.pov/settings.xml')
check_umb_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.umbrella/settings.xml')
check_shadow_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.shadow/settings.xml')
check_ghost_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.ghost/settings.xml')
check_unleashed_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.unleashed/settings.xml')
check_chains_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.thechains/settings.xml')
check_md_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.magicdragon/settings.xml')
check_asgard_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.asgard/settings.xml')
check_moria_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.moria/settings.xml')
check_base_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.base19/settings.xml')
check_twisted_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.twisted/settings.xml')
check_metv_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.metv19/settings.xml')
check_premiumizer_settings= xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.premiumizerx/settings.xml')
check_realizer_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.realizerx/rdauth.json')
check_rurl_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.ghost/settings.xml')
check_myaccounts_settings = xbmcvfs.translatePath('special://userdata/addon_data/script.module.myaccounts/settings.xml')
