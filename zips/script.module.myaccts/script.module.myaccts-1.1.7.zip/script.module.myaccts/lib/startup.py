import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import os.path
from myaccts.modules import var

def startup_sync():
        if str(var.check_myaccts_rd) != '': #Skip sync if Real-Debrid is not authorized
                from myaccts.modules import debrid_rd
                debrid_rd.debrid_auth_rd() #Sync Real-Debrid
        if str(var.check_myaccts_pm) != '': #Skip sync if Premiumize is not authorized
                from myaccts.modules import debrid_pm
                debrid_pm.debrid_auth_pm() #Sync Premiumize
        if str(var.check_myaccts_ad) != '': #Skip sync if All-Debrid is not authorized
                from myaccts.modules import debrid_ad 
                debrid_ad.debrid_auth_ad() #Sync All-Debrid

if var.setting('sync.service')=='true':
        startup_sync()
else:
        quit()
