import xbmc, xbmcaddon
import xbmcvfs
import json
from pathlib import Path
from myaccts.modules import control
from myaccts.modules import var

#Seren RD
def serenrd_auth():

        if xbmcvfs.exists(var.check_addon_seren) and xbmcvfs.exists(var.check_seren_settings): #Check that the addon is installed and settings.xml exists
                check_seren = xbmcaddon.Addon('plugin.video.seren').getSetting("rd.auth")
                check_seren_pm = xbmcaddon.Addon('plugin.video.seren').getSetting("premiumize.token")
                check_seren_ad = xbmcaddon.Addon('plugin.video.seren').getSetting("alldebrid.apikey")
                if not str(var.check_myaccts_rd) == str(check_seren) or str(check_seren) == '': #Compare Account Mananger token to Add-on token. If they match authorization is skipped

                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                        
                        #Write debrid data to settings.xml
                        addon = xbmcaddon.Addon("plugin.video.seren")
                        addon.setSetting("rd.username", your_username)
                        addon.setSetting("rd.auth", your_token)
                        addon.setSetting("rd.client_id", your_client_id)
                        addon.setSetting("rd.refresh", your_refresh)
                        addon.setSetting("rd.secret", your_secret)

                        premium_stat = ("Premium")
                        addon.setSetting("realdebrid.premiumstatus", premium_stat)
                        
                        #Set enabled for authorized debrid services
                        enabled_rd = ("true")
                        addon.setSetting("realdebrid.enabled", enabled_rd)
                
                        if str(check_seren_pm) != '': #Check if add-on is authorized
                                enabled_pm = ("true")
                                addon.setSetting("premiumize.enabled", enabled_pm)
                        else:
                                enabled_pm = ("false")
                                addon.setSetting("premiumize.enabled", enabled_pm)

                        if str(check_seren_ad) != '': #Check if add-on is authorized
                                enabled_ad = ("true")
                                addon.setSetting("alldebrid.enabled", enabled_ad)
                        else:
                                enabled_ad = ("false")
                                addon.setSetting("alldebrid.enabled", enabled_ad)
              

#Ezra RD
def ezrard_auth():

        if xbmcvfs.exists(var.check_addon_ezra) and xbmcvfs.exists(var.check_ezra_settings):
                check_ezra = xbmcaddon.Addon('plugin.video.ezra').getSetting("rd.token")
                check_ezra_pm = xbmcaddon.Addon('plugin.video.ezra').getSetting("pm.token")
                check_ezra_ad = xbmcaddon.Addon('plugin.video.ezra').getSetting("ad.token")
                if not str(var.check_myaccts_rd) == str(check_ezra) or str(check_ezra) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("plugin.video.ezra")
                        addon.setSetting("rd.username", your_username)
                        addon.setSetting("rd.token", your_token)
                        addon.setSetting("rd.client_id", your_client_id)
                        addon.setSetting("rd.refresh", your_refresh)
                        addon.setSetting("rd.secret", your_secret)

                        enabled_rd = ("true")
                        addon.setSetting("rd.enabled", enabled_rd)

                        if str(check_ezra_pm) != '':
                                enabled_pm = ("true")
                                addon.setSetting("pm.enabled", enabled_pm)
                        else:
                                enabled_pm = ("false")
                                addon.setSetting("pm.enabled", enabled_pm)
                
                        if str(check_ezra_ad) != '':
                                enabled_ad = ("true")
                                addon.setSetting("ad.enabled", enabled_ad)
                        else:
                                enabled_ad = ("false")
                                addon.setSetting("ad.enabled", enabled_ad)


#Fen RD
def fenrd_auth():
        
        if xbmcvfs.exists(var.check_addon_fen) and xbmcvfs.exists(var.check_fen_settings):
                check_fen = xbmcaddon.Addon('plugin.video.fen').getSetting("rd.token")
                check_fen_pm = xbmcaddon.Addon('plugin.video.fen').getSetting("pm.token")
                check_fen_ad = xbmcaddon.Addon('plugin.video.fen').getSetting("ad.token")
                if not str(var.check_myaccts_rd) == str(check_fen) or str(check_fen) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("plugin.video.fen")
                        addon.setSetting("rd.account_id", your_username)
                        addon.setSetting("rd.token", your_token)
                        addon.setSetting("rd.client_id", your_client_id)
                        addon.setSetting("rd.refresh", your_refresh)
                        addon.setSetting("rd.secret", your_secret)

                        enabled_rd = ("true")
                        addon.setSetting("rd.enabled", enabled_rd)

                        if str(check_fen_pm) != '':
                                enabled_pm = ("true")
                                addon.setSetting("pm.enabled", enabled_pm)
                        else:
                                enabled_pm = ("false")
                                addon.setSetting("pm.enabled", enabled_pm)
                
                        if str(check_fen_ad) != '':
                                enabled_ad = ("true")
                                addon.setSetting("ad.enabled", enabled_ad)
                        else:
                                enabled_ad = ("false")
                                addon.setSetting("ad.enabled", enabled_ad)
#POV RD
def povrd_auth():
        
        if xbmcvfs.exists(var.check_addon_pov) and xbmcvfs.exists(var.check_pov_settings):
                check_pov = xbmcaddon.Addon('plugin.video.pov').getSetting("rd.token")
                check_pov_pm = xbmcaddon.Addon('plugin.video.pov').getSetting("pm.token")
                check_pov_ad = xbmcaddon.Addon('plugin.video.pov').getSetting("ad.token")
                if not str(var.check_myaccts_rd) == str(check_pov) or str(check_pov) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("plugin.video.pov")
                        addon.setSetting("rd.username", your_username)
                        addon.setSetting("rd.token", your_token)
                        addon.setSetting("rd.client_id", your_client_id)
                        addon.setSetting("rd.refresh", your_refresh)
                        addon.setSetting("rd.secret", your_secret)

                        enabled_rd = ("true")
                        addon.setSetting("rd.enabled", enabled_rd)

                        if str(check_pov_pm) != '':
                                enabled_pm = ("true")
                                addon.setSetting("pm.enabled", enabled_pm)
                        else:
                                enabled_pm = ("false")
                                addon.setSetting("pm.enabled", enabled_pm)
                
                        if str(check_pov_ad) != '':
                                enabled_ad = ("true")
                                addon.setSetting("ad.enabled", enabled_ad)
                        else:
                                enabled_ad = ("false")
                                addon.setSetting("ad.enabled", enabled_ad)


#Umbrella RD
def umbrd_auth():
        
        if xbmcvfs.exists(var.check_addon_umb) and xbmcvfs.exists(var.check_umb_settings):
                check_umb = xbmcaddon.Addon('plugin.video.umbrella').getSetting("realdebridtoken")
                check_umb_pm = xbmcaddon.Addon('plugin.video.umbrella').getSetting("premiumizetoken")
                check_umb_ad = xbmcaddon.Addon('plugin.video.umbrella').getSetting("alldebridtoken")
                if not str(var.check_myaccts_rd) == str(check_umb) or str(check_umb) == '':
                
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("plugin.video.umbrella")
                        addon.setSetting("realdebridusername", your_username)
                        addon.setSetting("realdebridtoken", your_token)
                        addon.setSetting("realdebrid.clientid", your_client_id)
                        addon.setSetting("realdebridrefresh", your_refresh)
                        addon.setSetting("realdebridsecret", your_secret)

                        enabled_rd = ("true")
                        addon.setSetting("realdebrid.enabled", enabled_rd)

         
                        if str(check_umb_pm) != '':
                                enabled_pm = ("true")
                                addon.setSetting("premiumize.enabled", enabled_pm)
                        else:
                                enabled_pm = ("false")
                                addon.setSetting("premiumize.enabled", enabled_pm)

                        if str(check_umb_ad) != '':
                                enabled_ad = ("true")
                                addon.setSetting("alldebrid.enabled", enabled_ad)
                        else:
                                enabled_ad = ("false")
                                addon.setSetting("alldebrid.enabled", enabled_ad)


#Shadow RD
def shadowrd_auth():
        
        if xbmcvfs.exists(var.check_addon_shadow) and xbmcvfs.exists(var.check_shadow_settings):
                check_shadow = xbmcaddon.Addon('plugin.video.shadow').getSetting("rd.auth")
                check_shadow_pm = xbmcaddon.Addon('plugin.video.shadow').getSetting("premiumize.token")
                check_shadow_ad = xbmcaddon.Addon('plugin.video.shadow').getSetting("alldebrid.token")
                if not str(var.check_myaccts_rd) == str(check_shadow) or str(check_shadow) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("plugin.video.shadow")
                        addon.setSetting("rd.auth", your_token)
                        addon.setSetting("rd.client_id", your_client_id)
                        addon.setSetting("rd.refresh", your_refresh)
                        addon.setSetting("rd.secret", your_secret)

                        rd_use = ("true")
                        addon.setSetting("debrid_use_rd", rd_use)

                        if str(check_shadow_pm) != '':
                                pm_use = ("true")
                                addon.setSetting("debrid_use_pm", pm_use)
                        else:
                                pm_use = ("false")
                                addon.setSetting("debrid_use_pm", pm_use)
                                
                        if str(check_shadow_ad) != '':
                                ad_use = ("true")
                                addon.setSetting("debrid_use_ad", ad_use)
                        else:
                                ad_use = ("false")
                                addon.setSetting("debrid_use_ad", ad_use)
                               
#Ghost RD
def ghostrd_auth():
        
        if xbmcvfs.exists(var.check_addon_ghost) and xbmcvfs.exists(var.check_ghost_settings):
                check_ghost = xbmcaddon.Addon('plugin.video.ghost').getSetting("rd.auth")
                if not str(var.check_myaccts_rd) == str(check_ghost) or str(check_ghost) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("plugin.video.ghost")
                        addon.setSetting("rd.auth", your_token)
                        addon.setSetting("rd.client_id", your_client_id)
                        addon.setSetting("rd.refresh", your_refresh)
                        addon.setSetting("rd.secret", your_secret)

                        d_select = ("0")
                        addon.setSetting("debrid_select", d_select)


#Unleashed RD
def unleashedrd_auth():
        
        if xbmcvfs.exists(var.check_addon_unleashed) and xbmcvfs.exists(var.check_unleashed_settings):
                check_unleashed = xbmcaddon.Addon('plugin.video.unleashed').getSetting("rd.auth")
                if not str(var.check_myaccts_rd) == str(check_unleashed) or str(check_unleashed) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("plugin.video.unleashed")
                        addon.setSetting("rd.auth", your_token)
                        addon.setSetting("rd.client_id", your_client_id)
                        addon.setSetting("rd.refresh", your_refresh)
                        addon.setSetting("rd.secret", your_secret)

                        d_select = ("0")
                        addon.setSetting("debrid_select", d_select)


#Chains RD
def chainsrd_auth():
        
        if xbmcvfs.exists(var.check_addon_chains) and xbmcvfs.exists(var.check_chains_settings):
                check_chains = xbmcaddon.Addon('plugin.video.thechains').getSetting("rd.auth")
                if not str(var.check_myaccts_rd) == str(check_chains) or str(check_chains) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("plugin.video.thechains")
                        addon.setSetting("rd.auth", your_token)
                        addon.setSetting("rd.client_id", your_client_id)
                        addon.setSetting("rd.refresh", your_refresh)
                        addon.setSetting("rd.secret", your_secret)

                        d_select = ("0")
                        addon.setSetting("debrid_select", d_select)


#Moria RD
def moriard_auth():
        
        if xbmcvfs.exists(var.check_addon_moria) and xbmcvfs.exists(var.check_moria_settings):
                check_moria = xbmcaddon.Addon('plugin.video.moria').getSetting("rd.auth")
                if not str(var.check_myaccts_rd) == str(check_moria) or str(check_moria) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("plugin.video.moria")
                        addon.setSetting("rd.auth", your_token)
                        addon.setSetting("rd.client_id", your_client_id)
                        addon.setSetting("rd.refresh", your_refresh)
                        addon.setSetting("rd.secret", your_secret)

                        d_select = ("0")
                        addon.setSetting("debrid_select", d_select)


#Base 19 RD
def baserd_auth():
        
        if xbmcvfs.exists(var.check_addon_base) and xbmcvfs.exists(var.check_base_settings):
                check_base = xbmcaddon.Addon('plugin.video.base19').getSetting("rd.auth")
                if not str(var.check_myaccts_rd) == str(check_base) or str(check_base) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("plugin.video.base19")
                        addon.setSetting("rd.auth", your_token)
                        addon.setSetting("rd.client_id", your_client_id)
                        addon.setSetting("rd.refresh", your_refresh)
                        addon.setSetting("rd.secret", your_secret)

                        d_select = ("0")
                        addon.setSetting("debrid_select", d_select)


#Twisted RD
def twistedrd_auth():
        
        if xbmcvfs.exists(var.check_addon_twisted) and xbmcvfs.exists(var.check_twisted_settings):
                check_twisted = xbmcaddon.Addon('plugin.video.twisted').getSetting("rd.auth")
                if not str(var.check_myaccts_rd) == str(check_twisted) or str(check_twisted) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("plugin.video.twisted")
                        addon.setSetting("rd.auth", your_token)
                        addon.setSetting("rd.client_id", your_client_id)
                        addon.setSetting("rd.refresh", your_refresh)
                        addon.setSetting("rd.secret", your_secret)

                        d_select = ("0")
                        addon.setSetting("debrid_select", d_select)


#Magic Dragon RD
def mdrd_auth():
        
        if xbmcvfs.exists(var.check_addon_md) and xbmcvfs.exists(var.check_md_settings):
                check_md = xbmcaddon.Addon('plugin.video.magicdragon').getSetting("rd.auth")
                if not str(var.check_myaccts_rd) == str(check_md) or str(check_md) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("plugin.video.magicdragon")
                        addon.setSetting("rd.auth", your_token)
                        addon.setSetting("rd.client_id", your_client_id)
                        addon.setSetting("rd.refresh", your_refresh)
                        addon.setSetting("rd.secret", your_secret)

                        d_select = ("0")
                        addon.setSetting("debrid_select", d_select)


#Asgard RD
def asgardrd_auth():
        
        if xbmcvfs.exists(var.check_addon_asgard) and xbmcvfs.exists(var.check_asgard_settings):
                check_asgard = xbmcaddon.Addon('plugin.video.asgard').getSetting("rd.auth")
                if not str(var.check_myaccts_rd) == str(check_asgard) or str(check_asgard) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("plugin.video.asgard")
                        addon.setSetting("rd.auth", your_token)
                        addon.setSetting("rd.client_id", your_client_id)
                        addon.setSetting("rd.refresh", your_refresh)
                        addon.setSetting("rd.secret", your_secret)

                        d_select = ("0")
                        addon.setSetting("debrid_select", d_select)


#M.E.T.V RD
def metvrd_auth():
        
        if xbmcvfs.exists(var.check_addon_metv) and xbmcvfs.exists(var.check_metv_settings):
                check_metv = xbmcaddon.Addon('plugin.video.metv19').getSetting("rd.auth")
                if not str(var.check_myaccts_rd) == str(check_metv) or str(check_metv) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("plugin.video.metv19")
                        addon.setSetting("rd.auth", your_token)
                        addon.setSetting("rd.client_id", your_client_id)
                        addon.setSetting("rd.refresh", your_refresh)
                        addon.setSetting("rd.secret", your_secret)

                        d_select = ("0")
                        addon.setSetting("debrid_select", d_select)


#ResolveURL RD
def rurlrd_auth():
        
        if xbmcvfs.exists(var.check_addon_rurl) and xbmcvfs.exists(var.check_rurl_settings):
                check_rurl = xbmcaddon.Addon('script.module.resolveurl').getSetting("RealDebridResolver_token")
                if not str(var.check_myaccts_rd) == str(check_rurl) or str(check_rurl) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("script.module.resolveurl")
                        addon.setSetting("RealDebridResolver_login", your_username)
                        addon.setSetting("RealDebridResolver_token", your_token)
                        addon.setSetting("RealDebridResolver_client_id", your_client_id)
                        addon.setSetting("RealDebridResolver_refresh", your_refresh)
                        addon.setSetting("RealDebridResolver_client_secret", your_secret)

                        cache_only = ("true")
                        addon.setSetting("RealDebridResolver_cached_only", cache_only)


#My Accounts RD
def myaccountsrd_auth():

        if xbmcvfs.exists(var.check_addon_myaccounts) and xbmcvfs.exists(var.check_myaccounts_settings):
                check_myaccounts = xbmcaddon.Addon('script.module.myaccounts').getSetting("realdebrid.token")
                if not str(var.check_myaccts_rd) == str(check_myaccounts) or str(check_myaccounts) == '':
                        
                        myaccts = xbmcaddon.Addon("script.module.myaccts")
                        your_username = myaccts.getSetting("realdebrid.username")
                        your_token = myaccts.getSetting("realdebrid.token")
                        your_client_id = myaccts.getSetting("realdebrid.client_id")
                        your_refresh = myaccts.getSetting("realdebrid.refresh")
                        your_secret = myaccts.getSetting("realdebrid.secret")
                
                        addon = xbmcaddon.Addon("script.module.myaccounts")
                        addon.setSetting("realdebrid.username", your_username)
                        addon.setSetting("realdebrid.token", your_token)
                        addon.setSetting("realdebrid.client_id", your_client_id)
                        addon.setSetting("realdebrid.refresh", your_refresh)
                        addon.setSetting("realdebrid.secret", your_secret)

#Realizer RD
def realizer_auth():

        if xbmcvfs.exists(var.check_addon_realizer) and xbmcvfs.exists(var.check_realizer_settings):

                rdauth = {}
                myaccts = xbmcaddon.Addon('script.module.myaccts')
                rdauth = {'client_id': myaccts.getSetting('realdebrid.client_id'), 'client_secret': myaccts.getSetting('realdebrid.secret'), 'token': myaccts.getSetting('realdebrid.token'), 'refresh_token': myaccts.getSetting('realdebrid.refresh'), 'added': '202301010243'}

                with open(var.realizer_path, 'w') as debrid_write:
                        json.dump(rdauth, debrid_write)
                        
def debrid_auth_rd(): #Sync all add-ons
               serenrd_auth()
               ezrard_auth()
               fenrd_auth()
               povrd_auth()
               umbrd_auth()
               shadowrd_auth()
               ghostrd_auth()
               unleashedrd_auth()
               chainsrd_auth()
               moriard_auth()
               baserd_auth()
               twistedrd_auth()
               mdrd_auth()
               asgardrd_auth()
               metvrd_auth()
               rurlrd_auth()
               myaccountsrd_auth()
               realizer_auth()
