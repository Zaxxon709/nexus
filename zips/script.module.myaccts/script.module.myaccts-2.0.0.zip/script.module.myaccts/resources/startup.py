import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import os.path
import time

joinPath = os.path.join
dialog = xbmcgui.Dialog()
addon = xbmcaddon.Addon
addonObject = addon('script.module.myaccts')
addonInfo = addonObject.getAddonInfo
rd_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.myaccts').getAddonInfo('path'), 'resources', 'icons'), 'realdebrid.png')
pm_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.myaccts').getAddonInfo('path'), 'resources', 'icons'), 'premiumize.png')
ad_icon = joinPath(os.path.join(xbmcaddon.Addon('script.module.myaccts').getAddonInfo('path'), 'resources', 'icons'), 'alldebrid.png')

timeout_start = time.time()
timeout = 60*5 #Time out 5min from now

def notification(title=None, message=None, icon=None, time=3000, sound=False):
	if title == 'default' or title is None: title = addonName()
	if isinstance(title, int): heading = lang(title)
	else: heading = str(title)
	if isinstance(message, int): body = lang(message)
	else: body = str(message)
	if icon is None or icon == '' or icon == 'default': icon = addonIcon()
	elif icon == 'INFO': icon = xbmcgui.NOTIFICATION_INFO
	elif icon == 'WARNING': icon = xbmcgui.NOTIFICATION_WARNING
	elif icon == 'ERROR': icon = xbmcgui.NOTIFICATION_ERROR
	dialog.notification(heading, body, icon, time, sound=sound)

def addonIcon():
	return addonInfo('icon')

def addonName():
	return addonInfo('name')

def api_check():

        check_api = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
        check_myaccts = xbmcaddon.Addon('script.module.myaccts').getSetting("trakt.token")

        check_addon_seren = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/')
        check_addon_fen = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/')
        check_addon_pov = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/')
        check_addon_umb = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/')
        check_addon_home = xbmcvfs.translatePath('special://home/addons/plugin.video.homelander/')
        check_addon_genocide = xbmcvfs.translatePath('special://home/addons/plugin.video.chainsgenocide/')
        check_addon_crew = xbmcvfs.translatePath('special://home/addons/plugin.video.thecrew/')
        check_addon_shazam = xbmcvfs.translatePath('special://home/addons/plugin.video.shazam/')
        check_addon_night = xbmcvfs.translatePath('special://home/addons/plugin.video.nightwing/')
        check_addon_promise = xbmcvfs.translatePath('special://home/addons/plugin.video.thepromise/')
        check_addon_scrubs = xbmcvfs.translatePath('special://home/addons/plugin.video.scrubsv2/')
        check_addon_alvin = xbmcvfs.translatePath('special://home/addons/plugin.video.alvin/')
        check_addon_shadow = xbmcvfs.translatePath('special://home/addons/plugin.video.shadow/')
        check_addon_ghost = xbmcvfs.translatePath('special://home/addons/plugin.video.ghost/')
        check_addon_unleashed = xbmcvfs.translatePath('special://home/addons/plugin.video.unleashed/')
        check_addon_chains = xbmcvfs.translatePath('special://home/addons/plugin.video.thechains/')
        check_addon_md = xbmcvfs.translatePath('special://home/addons/plugin.video.magicdragon/')
        check_addon_asgard = xbmcvfs.translatePath('special://home/addons/plugin.video.asgard/')
        check_addon_myaccounts = xbmcvfs.translatePath('special://home/addons/script.module.myaccounts/')
        check_addon_tmdbh = xbmcvfs.translatePath('special://home/addons/plugin.video.themoviedb.helper/')
        check_addon_trakt = xbmcvfs.translatePath('special://home/addons/script.trakt/')
        
        check_seren_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.seren/settings.xml')
        check_fen_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.fen/settings.xml')
        check_ezra_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.ezra/settings.xml')
        check_pov_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.pov/settings.xml')
        check_umb_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.umbrella/settings.xml')
        check_home_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.homelander/settings.xml')
        check_genocide_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.chainsgenocide/settings.xml')
        check_crew_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.thecrew/settings.xml')
        check_shazam_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.shazam/settings.xml')
        check_night_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.nightwing/settings.xml')
        check_promise_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.thepromise/settings.xml')
        check_scrubs_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.scrubsv2/settings.xml')
        check_alvin_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.alvin/settings.xml')
        check_shadow_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.shadow/settings.xml')
        check_ghost_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.ghost/settings.xml')
        check_unleashed_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.unleashed/settings.xml')
        check_chains_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.thechains/settings.xml')
        check_md_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.magicdragon/settings.xml')
        check_asgard_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.asgard/settings.xml')
        check_myaccounts_settings = xbmcvfs.translatePath('special://userdata/addon_data/script.module.myaccounts/settings.xml')
        check_tmdbh_settings = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/settings.xml')
        check_trakt_settings = xbmcvfs.translatePath('special://userdata/addon_data/script.trakt/settings.xml')
        
        client_keys_seren = xbmcvfs.translatePath('special://home/addons/plugin.video.seren/resources/lib/indexers/trakt.py')
        client_keys_fen = xbmcvfs.translatePath('special://home/addons/plugin.video.fen/resources/lib/apis/trakt_api.py')
        client_keys_pov = xbmcvfs.translatePath('special://home/addons/plugin.video.pov/resources/lib/apis/trakt_api.py')
        client_keys_umb = xbmcvfs.translatePath('special://home/addons/plugin.video.umbrella/resources/lib/modules/trakt.py')
        client_keys_home = xbmcvfs.translatePath('special://home/addons/plugin.video.homelander/resources/lib/modules/trakt.py')
        client_keys_genocide = xbmcvfs.translatePath('special://home/addons/plugin.video.chainsgenocide/resources/lib/modules/trakt.py')
        client_keys_crew = xbmcvfs.translatePath('special://home/addons/script.module.thecrew/lib/resources/lib/modules/trakt.py')
        client_keys_shazam = xbmcvfs.translatePath('special://home/addons/plugin.video.shazam/resources/lib/modules/trakt.py')
        client_keys_night = xbmcvfs.translatePath('special://home/addons/plugin.video.nightwing/resources/lib/modules/trakt.py')
        client_keys_home = xbmcvfs.translatePath('special://home/addons/plugin.video.homelander/resources/lib/modules/trakt.py')
        client_keys_promise = xbmcvfs.translatePath('special://home/addons/plugin.video.thepromise/resources/lib/modules/trakt.py')
        client_keys_scrubs = xbmcvfs.translatePath('special://home/addons/plugin.video.scrubsv2/resources/lib/modules/trakt.py')
        client_keys_alvin = xbmcvfs.translatePath('special://home/addons/plugin.video.alvin/resources/lib/modules/trakt.py')
        client_keys_shadow = xbmcvfs.translatePath('special://home/addons/plugin.video.shadow/resources/modules/general.py')
        client_keys_ghost = xbmcvfs.translatePath('special://home/addons/plugin.video.ghost/resources/modules/general.py')
        client_keys_unleashed = xbmcvfs.translatePath('special://home/addons/plugin.video.unleashed/resources/modules/general.py')
        client_keys_chains = xbmcvfs.translatePath('special://home/addons/plugin.video.thechains/resources/modules/general.py')
        client_keys_md = xbmcvfs.translatePath('special://home/addons/plugin.video.magicdragon/resources/modules/general.py')
        client_keys_asgard = xbmcvfs.translatePath('special://home/addons/plugin.video.asgard/resources/modules/general.py')
        client_keys_myaccounts = xbmcvfs.translatePath('special://home/addons/script.module.myaccounts/lib/myaccounts/modules/trakt.py')
        client_keys_tmdbh = xbmcvfs.translatePath('special://home/addons/plugin.video.themoviedb.helper/resources/tmdbhelper/lib/api/api_keys/trakt.py')
        client_keys_trakt = xbmcvfs.translatePath('special://home/addons/script.trakt/resources/lib/traktapi.py')
        
        while True:

                if time.time() > timeout_start + timeout: #Time out after 5min
                        break
        
                if xbmcvfs.exists(check_addon_seren) and xbmcvfs.exists(check_seren_settings) and str(check_myaccts) != '': #Check that the addon is installed, settings.xml exists and Account Manager is authorized
                        check_seren = xbmcaddon.Addon('plugin.video.seren').getSetting("trakt.auth")
                        if str(check_myaccts) == str(check_seren): #Compare Account Mananger token to Add-on token. If they match, continue with API check
                                with open(client_keys_seren) as f:
                                        if check_api in f.read():
                                                pass
                                        else:   #Insert Account Mananger API keys into add-on
                                                f = open(client_keys_seren,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'0c9a30819e4af6ffaf3b954cbeae9b54499088513863c03c02911de00ac2de79',client)
                                                f = open(client_keys_seren,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_seren,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'bf02417f27b514cee6a8d135f2ddc261a15eecfb6ed6289c36239826dcdd1842',secret)
                                                f = open(client_keys_seren,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue
              
                if xbmcvfs.exists(check_addon_fen) and xbmcvfs.exists(check_fen_settings) and str(check_myaccts) != '':
                        check_fen = xbmcaddon.Addon('plugin.video.fen').getSetting("trakt.token")
                        if str(check_fen) != '':
                                with open(client_keys_fen) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_fen,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'645b0f46df29d27e63c4a8d5fff158edd0bef0a6a5d32fc12c1b82388be351af',client)
                                                f = open(client_keys_fen,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_fen,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'422a282ef5fe4b5c47bc60425c009ac3047ebd10a7f6af790303875419f18f98',secret)
                                                f = open(client_keys_fen,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue
         
                if xbmcvfs.exists(check_addon_pov) and xbmcvfs.exists(check_pov_settings) and str(check_myaccts) != '':
                        check_pov = xbmcaddon.Addon('plugin.video.pov').getSetting("trakt.token")
                        if str(check_pov) != '':
                                with open(client_keys_pov) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_pov,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'd4161a7a106424551add171e5470112e4afdaf2438e6ef2fe0548edc75924868',client)
                                                f = open(client_keys_pov,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_pov,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'b5fcd7cb5d9bb963784d11bbf8535bc0d25d46225016191eb48e50792d2155c0',secret)
                                                f = open(client_keys_pov,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue
                                        
                if xbmcvfs.exists(check_addon_umb) and xbmcvfs.exists(check_umb_settings) and str(check_myaccts) != '':
                        check_umb = xbmcaddon.Addon('plugin.video.umbrella').getSetting("trakt.user.token")
                        if str(check_umb) != '':
                                with open(client_keys_umb) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_umb,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'87e3f055fc4d8fcfd96e61a47463327ca877c51e8597b448e132611c5a677b13',client)
                                                f = open(client_keys_umb,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_umb,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'4a1957a52d5feb98fafde53193e51f692fa9bdcd0cc13cf44a5e39975539edf0',secret)
                                                f = open(client_keys_umb,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue
                                        
                if xbmcvfs.exists(check_addon_home) and xbmcvfs.exists(check_home_settings) and str(check_myaccts) != '':
                        check_home = xbmcaddon.Addon('plugin.video.homelander').getSetting("trakt.token")
                        if str(check_home) != '':
                                with open(client_keys_home) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_home,'r')
                                                data = f.read()
                                                f.close()
                                                client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
                                                new_client = data.replace(f'api_keys.trakt_client_id',client)
                                                f = open(client_keys_home,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_home,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
                                                new_secret = data.replace(f'api_keys.trakt_secret',secret)
                                                f = open(client_keys_home,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue

                if xbmcvfs.exists(check_addon_genocide) and xbmcvfs.exists(check_genocide_settings) and str(check_myaccts) != '':
                        check_genocide = xbmcaddon.Addon('plugin.video.chainsgenocide').getSetting("trakt.token")
                        if str(check_genocide) != '':
                                with open(client_keys_genocide) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_genocide,'r')
                                                data = f.read()
                                                f.close()
                                                client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
                                                new_client = data.replace(f'api_keys.trakt_client_id',client)
                                                f = open(client_keys_genocide,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_genocide,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
                                                new_secret = data.replace(f'api_keys.trakt_secret',secret)
                                                f = open(client_keys_genocide,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue
                                        
                if xbmcvfs.exists(check_addon_crew) and xbmcvfs.exists(check_crew_settings) and str(check_myaccts) != '':
                        check_crew = xbmcaddon.Addon('plugin.video.thecrew').getSetting("trakt.token")
                        if str(check_crew) != '':
                                with open(client_keys_crew) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_crew,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'482f9db52ee2611099ce3aa1abf9b0f7ed893c6d3c6b5face95164eac7b01f71',client)
                                                f = open(client_keys_crew,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_crew,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'80a2729728b53ba1cc38137b22f21f34d590edd35454466c4b8920956513d967',secret)
                                                f = open(client_keys_crew,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue
                                        
                if xbmcvfs.exists(check_addon_shazam) and xbmcvfs.exists(check_shazam_settings) and str(check_myaccts) != '':
                        check_shazam = xbmcaddon.Addon('plugin.video.shazam').getSetting("trakt.token")
                        if str(check_shazam) != '':
                                with open(client_keys_shazam) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_shazam,'r')
                                                data = f.read()
                                                f.close()
                                                client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
                                                new_client = data.replace(f'api_keys.trakt_client_id',client)
                                                f = open(client_keys_shazam,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_shazam,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
                                                new_secret = data.replace(f'api_keys.trakt_secret',secret)
                                                f = open(client_keys_shazam,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue
                                        
                if xbmcvfs.exists(check_addon_night) and xbmcvfs.exists(check_night_settings) and str(check_myaccts) != '':
                        check_night = xbmcaddon.Addon('plugin.video.nightwing').getSetting("trakt.token")
                        if str(check_night) != '':
                                with open(client_keys_night) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_night,'r')
                                                data = f.read()
                                                f.close()
                                                client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
                                                new_client = data.replace(f'base64.b64decode("MjFiODhkNGRjZDU4ZjVlY2EzOTEyOGE3MzZkMjIxNmRhNTZiNTIxMTQ4MDUyNThjNGU5ZjlhNjNkOTgwMDcyMg==")',client)
                                                f = open(client_keys_night,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_night,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
                                                new_secret = data.replace(f'base64.b64decode("MjM4OGIzMDdkZDFiYTU0NGQ2ZmEwZTFmNTcxNDczNWJkNTIwYzhmZTM4ZGYyMTEyZDg4ODg1MmJhODE1YWRlOQ==")',secret)
                                                f = open(client_keys_night,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue

                if xbmcvfs.exists(check_addon_promise) and xbmcvfs.exists(check_promise_settings) and str(check_myaccts) != '':
                        check_promise = xbmcaddon.Addon('plugin.video.thepromise').getSetting("trakt.token")
                        if str(check_promise) != '':
                                with open(client_keys_promise) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_promise,'r')
                                                data = f.read()
                                                f.close()
                                                client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
                                                new_client = data.replace(f'api_keys.trakt_client_id',client)
                                                f = open(client_keys_promise,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_promise,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
                                                new_secret = data.replace(f'api_keys.trakt_secret',secret)
                                                f = open(client_keys_promise,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue

                if xbmcvfs.exists(check_addon_scrubs) and xbmcvfs.exists(check_scrubs_settings) and str(check_myaccts) != '':
                        check_scrubs = xbmcaddon.Addon('plugin.video.scrubsv2').getSetting("trakt.token")
                        if str(check_scrubs) != '':
                                with open(client_keys_scrubs) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_scrubs,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'63c53edc299b7a05cc6ea2272e8a84e13aade067c18a794362ab9a4a84eafb16',client)
                                                f = open(client_keys_scrubs,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_scrubs,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'9163ebda9d33acd06c74d017e861404b7212ee34675e09e73365d7536b84eab6',secret)
                                                f = open(client_keys_scrubs,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue

                if xbmcvfs.exists(check_addon_alvin) and xbmcvfs.exists(check_alvin_settings) and str(check_myaccts) != '':
                        check_alvin = xbmcaddon.Addon('plugin.video.alvin').getSetting("trakt.token")
                        if str(check_alvin) != '':
                                with open(client_keys_alvin) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_alvin,'r')
                                                data = f.read()
                                                f.close()
                                                client = f"'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'"
                                                new_client = data.replace(f'api_keys.trakt_client_id',client)
                                                f = open(client_keys_alvin,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_alvin,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f"'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'"
                                                new_secret = data.replace(f'api_keys.trakt_secret',secret)
                                                f = open(client_keys_alvin,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue

                if xbmcvfs.exists(check_addon_shadow) and xbmcvfs.exists(check_shadow_settings) and str(check_myaccts) != '':
                        check_shadow = xbmcaddon.Addon('plugin.video.shadow').getSetting("trakt.token")
                        if str(check_shadow) != '':
                                with open(client_keys_shadow) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_shadow,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'8ed545c0b7f92cc26d1ecd6326995c6cf0053bd7596a98e962a472bee63274e6',client)
                                                f = open(client_keys_shadow,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_shadow,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'1ec4f37e5743e3086abace0c83444c25d9b655d1d77b793806b2c8205a510426',secret)
                                                f = open(client_keys_shadow,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue

                if xbmcvfs.exists(check_addon_ghost) and xbmcvfs.exists(check_ghost_settings) and str(check_myaccts) != '':
                        check_ghost = xbmcaddon.Addon('plugin.video.ghost').getSetting("trakt.token")
                        if str(check_ghost) != '':
                                with open(client_keys_ghost) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_ghost,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'a4e716b4b22b62e59b9e09454435c8710b650b3143dcce553d252b6a66ba60c8',client)
                                                f = open(client_keys_ghost,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_ghost,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'c6d9aba72214a1ca3c6d45d0351e59f21bbe43df9bbac7c5b740089379f8c5cd',secret)
                                                f = open(client_keys_ghost,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue

                if xbmcvfs.exists(check_addon_unleashed) and xbmcvfs.exists(check_unleashed_settings) and str(check_myaccts) != '':
                        check_unleashed = xbmcaddon.Addon('plugin.video.unleashed').getSetting("trakt.token")
                        if str(check_unleashed) != '':
                                with open(client_keys_unleashed) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_unleashed,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'19849909a0f8c9dc632bc5f5c7ccafd19f3e452e2e44fee05b83fd5dc1e77675',client)
                                                f = open(client_keys_unleashed,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_unleashed,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'122b7a79437dcf4b657d3af9e92f2d9ff8939ade532e03bc81bfb5ce798b04bf',secret)
                                                f = open(client_keys_unleashed,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue
                                        
                if xbmcvfs.exists(check_addon_chains) and xbmcvfs.exists(check_chains_settings) and str(check_myaccts) != '':
                        check_chains = xbmcaddon.Addon('plugin.video.thechains').getSetting("trakt.token")
                        if str(check_chains) != '':
                                with open(client_keys_chains) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_chains,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'19849909a0f8c9dc632bc5f5c7ccafd19f3e452e2e44fee05b83fd5dc1e77675',client)
                                                f = open(client_keys_chains,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_chains,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'122b7a79437dcf4b657d3af9e92f2d9ff8939ade532e03bc81bfb5ce798b04bf',secret)
                                                f = open(client_keys_chains,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue

                if xbmcvfs.exists(check_addon_md) and xbmcvfs.exists(check_md_settings) and str(check_myaccts) != '':
                        check_md = xbmcaddon.Addon('plugin.video.magicdragon').getSetting("trakt.token")
                        if str(check_md) != '':
                                with open(client_keys_md) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_md,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'8ed545c0b7f92cc26d1ecd6326995c6cf0053bd7596a98e962a472bee63274e6',client)
                                                f = open(client_keys_md,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_md,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'1ec4f37e5743e3086abace0c83444c25d9b655d1d77b793806b2c8205a510426',secret)
                                                f = open(client_keys_md,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue

                if xbmcvfs.exists(check_addon_asgard) and xbmcvfs.exists(check_asgard_settings) and str(check_myaccts) != '':
                        check_asgard = xbmcaddon.Addon('plugin.video.asgard').getSetting("trakt.token")
                        if str(check_asgard) != '':
                                with open(client_keys_asgard) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_asgard,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'54de56f7b90a4cf7227fd70ecf703c6c043ec135c56ad10c9bb90c539bf2749f',client)
                                                f = open(client_keys_asgard,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_asgard,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'a43aa6bd62eb5afd37ede4a625457fc903f1961b8384178986bf76eebfcd5999',secret)
                                                f = open(client_keys_asgard,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue
                                        
                if xbmcvfs.exists(check_addon_myaccounts) and xbmcvfs.exists(check_myaccounts_settings) and str(check_myaccts) != '':
                        check_myaccounts = xbmcaddon.Addon('script.module.myaccounts').getSetting("trakt.token")
                        if str(check_myaccounts) != '':
                                with open(client_keys_myaccounts) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_myaccounts,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'e3a8d1c673dfecb7f669b23ecbf77c75fcfd24d3e8c3dbc7f79ed995262fa1db',client)
                                                f = open(client_keys_myaccounts,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_myaccounts,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'73bee6aeee29cb75db4d8771458a440017f7cfe842e85f457ed9d81f7910b349',secret)
                                                f = open(client_keys_myaccounts,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue

                if xbmcvfs.exists(check_addon_tmdbh) and xbmcvfs.exists(check_tmdbh_settings) and str(check_myaccts) != '':
                        check_tmdbh = xbmcaddon.Addon('plugin.video.themoviedb.helper').getSetting("Trakt_token")
                        if str(check_tmdbh) != '':
                                with open(client_keys_tmdbh) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_tmdbh,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'e6fde6173adf3c6af8fd1b0694b9b84d7c519cefc24482310e1de06c6abe5467',client)
                                                f = open(client_keys_tmdbh,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_tmdbh,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'15119384341d9a61c751d8d515acbc0dd801001d4ebe85d3eef9885df80ee4d9',secret)
                                                f = open(client_keys_tmdbh,'w')
                                                f.write(new_secret)
                                                f.close()
                                                continue

                if xbmcvfs.exists(check_addon_trakt) and xbmcvfs.exists(check_trakt_settings) and str(check_myaccts) != '':
                        check_trakt = xbmcaddon.Addon('script.trakt').getSetting("authorization")
                        if str(check_trakt) != '':
                                with open(client_keys_trakt) as f:
                                        if check_api in f.read():
                                                pass
                                        else:
                                                f = open(client_keys_trakt,'r')
                                                data = f.read()
                                                f.close()
                                                client = f'4a479b95c8224999eef8d418cfe6c7a4389e2837441672c48c9c8168ea42a407'
                                                new_client = data.replace(f'd4161a7a106424551add171e5470112e4afdaf2438e6ef2fe0548edc75924868',client)
                                                f = open(client_keys_trakt,'w')
                                                f.write(new_client)
                                                f.close()

                                                f = open(client_keys_trakt,'r')
                                                data = f.read()
                                                f.close()
                                                secret = f'89d8f8f71b312985a9e1f91e9eb426e23050102734bb1fa36ec76cdc74452ab6'
                                                new_secret = data.replace(f'b5fcd7cb5d9bb963784d11bbf8535bc0d25d46225016191eb48e50792d2155c0',secret)
                                                f = open(client_keys_trakt,'w')
                                                f.write(new_secret)
                                                f.close()
                                                pass


                xbmc.sleep(10000) #Pause for 10 seconds and then continue API check loop

api_check()
