import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'http://dr-venture.com/709/Wizard/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://dr-venture.com/709/Wizard/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
