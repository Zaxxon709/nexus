import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://dr-venture.com/709/Wizard/Nexus/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://dr-venture.com/709/Wizard/Nexus/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
