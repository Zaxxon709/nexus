import xbmc
import xbmcplugin
import xbmcaddon
import sys
import os
from .params import Params
from .menu import main_menu

handle = int(sys.argv[1])

def router(paramstring):

    p = Params(paramstring)
    xbmc.log(str(p.get_params()),xbmc.LOGDEBUG)

    mode = p.get_mode()
    
    xbmcplugin.setContent(handle, 'files')

    if mode is None:
        main_menu()
        
    elif mode == 1:
        from resources.lib.modules import maxql_1080p
        maxql_1080p.hd.hd_config()

    elif mode == 2:
        from resources.lib.modules import maxql_4k
        maxql_4k.full_hd.fullhd_config()
        
    elif mode == 3:
        from resources.lib.modules import maxql_dv_enable
        maxql_dv_enable.dv.dv_enable()
        
    elif mode == 4:
        from resources.lib.modules import maxql_dv_disable
        maxql_dv_disable.dv.dv_disable()

    elif mode == 5:
        from resources.lib.modules import maxql_3d_enable
        maxql_3d_enable.three_d.threed_enable()

    elif mode == 6:
        from resources.lib.modules import maxql_3d_disable
        maxql_3d_disable.three_d.threed_disable()

    xbmcplugin.endOfDirectory(handle)
