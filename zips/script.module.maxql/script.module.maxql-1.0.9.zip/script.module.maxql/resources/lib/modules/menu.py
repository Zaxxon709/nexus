import sys
import json
import xbmc
import xbmcplugin
from .utils import add_dir

addon_fanart = 'special://home/addons/script.module.maxql/icons/fanart.jpg'
min_icon = 'special://home/addons/script.module.maxql/icons/1080p.png'
max_icon = 'special://home/addons/script.module.maxql/icons/4k.png'
on_icon = 'special://home/addons/script.module.maxql/icons/on.png'
off_icon = 'special://home/addons/script.module.maxql/icons/off.png'

handle = int(sys.argv[1])

def main_menu():
    xbmcplugin.setPluginCategory(handle, 'Main Menu')

    add_dir('Enable Max 1080P Resolution','',1,min_icon,addon_fanart,isFolder=True)
    
    add_dir('Enable Max 4K Resolution','',2,max_icon,addon_fanart,isFolder=True)

    add_dir('Enable Dolby Vision','',3,on_icon,addon_fanart,isFolder=True)

    add_dir('Disable Dolby Vision','',4,off_icon,addon_fanart,isFolder=True)

    add_dir('Enable 3D','',5,on_icon,addon_fanart,isFolder=True)

    add_dir('Disable 3D','',6,off_icon,addon_fanart,isFolder=True)


