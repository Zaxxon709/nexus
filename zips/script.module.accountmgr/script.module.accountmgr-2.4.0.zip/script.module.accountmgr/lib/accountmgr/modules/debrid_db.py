import xbmc, xbmcaddon
import sqlite3
import xbmcvfs
import os
from libs.common import var
from sqlite3 import Error

#Account Manager Real-Debrid
accountmgr = xbmcaddon.Addon("script.module.accountmgr")
your_rd_username = accountmgr.getSetting("realdebrid.username")
your_rd_token = accountmgr.getSetting("realdebrid.token")
your_rd_client_id = accountmgr.getSetting("realdebrid.client_id")
your_rd_refresh = accountmgr.getSetting("realdebrid.refresh")
your_rd_secret = accountmgr.getSetting("realdebrid.secret")
your_rd_expiry = accountmgr.getSetting("realdebrid.expiry.notice")

#Account Manager Premiumize
your_pm_username = accountmgr.getSetting("premiumize.username")
your_pm_token = accountmgr.getSetting("premiumize.token")

#Account Manager All-Debrid
your_ad_username = accountmgr.getSetting("alldebrid.username")
your_ad_token = accountmgr.getSetting("alldebrid.token")

#Connect to database
def create_conn(db_file):
    try:
        conn = None
        try:
            conn = sqlite3.connect(db_file)
        except Error as e:
            print(e)

        return conn
    except:
        pass
    
#Fen Light RD
def connect_fenlt_rd(conn, setting):
    try:
        # Update settings database
        rd_enable = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        rd_token = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        rd_account_id = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        rd_client_id = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        rd_refresh = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        rd_secret = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(rd_enable, setting)
        cur.execute(rd_token, setting)
        cur.execute(rd_account_id, setting)
        cur.execute(rd_client_id, setting)
        cur.execute(rd_refresh, setting)
        cur.execute(rd_secret, setting)
        conn.commit()
        cur.close()
    except:
        pass
    
#Auth RD
def auth_fenlt_rd():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            connect_fenlt_rd(conn, ('true', 'rd.enabled'))
            connect_fenlt_rd(conn, (your_rd_token, 'rd.token'))
            connect_fenlt_rd(conn, (your_rd_username, 'rd.account_id'))
            connect_fenlt_rd(conn, (your_rd_client_id, 'rd.client_id'))
            connect_fenlt_rd(conn, (your_rd_refresh, 'rd.refresh'))
            connect_fenlt_rd(conn, (your_rd_secret, 'rd.secret'))
    except:
        pass
    
#Enable RD
def enable_rd(conn, setting):
    try:
        # Update settings database
        rd_enable = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(rd_enable, setting)
        conn.commit()
        cur.close()
    except:
        pass
    
def enable_fenlt_rd():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            enable_rd(conn, ('true', 'rd.enabled'))
    except:
        pass
    
#Disable RD
def disable_rd(conn, setting):
    try:
        # Update settings database
        rd_disable = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(rd_disable, setting)
        conn.commit()
        cur.close()
    except:
        pass
    
def disable_fenlt_rd():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            disable_rd(conn, ('false', 'rd.enabled'))
    except:
        pass



#Fen Light PM
def connect_fenlt_pm(conn, setting):
    try:
        # Update settings database
        pm_enable = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        pm_token = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        pm_account_id = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(pm_enable, setting)
        cur.execute(pm_token, setting)
        cur.execute(pm_account_id, setting)
        conn.commit()
        cur.close()
    except:
        pass
    
#Auth PM
def auth_fenlt_pm():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            connect_fenlt_pm(conn, ('true', 'pm.enabled'))
            connect_fenlt_pm(conn, (your_pm_token, 'pm.token'))
            connect_fenlt_pm(conn, (your_pm_username, 'pm.account_id'))
    except:
        pass
    
#Enable PM
def enable_pm(conn, setting):
    try:
        # Update settings database
        pm_enable = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(pm_enable, setting)
        conn.commit()
        cur.close()
    except:
        pass
    
def enable_fenlt_pm():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            enable_pm(conn, ('true', 'pm.enabled'))
    except:
        pass
    
#Disable PM
def disable_pm(conn, setting):
    try:
        # Update settings database
        pm_disable = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(pm_disable, setting)
        conn.commit()
        cur.close()
    except:
        pass
    
def disable_fenlt_pm():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            disable_pm(conn, ('false', 'pm.enabled'))
    except:
        pass
    


#Fen Light AD
def connect_fenlt_ad(conn, setting):
    try:
        # Update settings database
        ad_enable = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        ad_token = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''
        ad_account_id = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(ad_enable, setting)
        cur.execute(ad_token, setting)
        cur.execute(ad_account_id, setting)
        conn.commit()
        cur.close()
    except:
        pass
    
#Auth AD
def auth_fenlt_ad():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            connect_fenlt_ad(conn, ('true', 'ad.enabled'))
            connect_fenlt_ad(conn, (your_ad_token, 'ad.token'))
            connect_fenlt_ad(conn, (your_ad_username, 'ad.account_id'))
    except:
        pass
    
#Revoke AD
def revoke_fenlt_ad():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            connect_fenlt_ad(conn, ('', 'ad.enabled'))
            connect_fenlt_ad(conn, ('', 'ad.token'))
            connect_fenlt_ad(conn, ('', 'ad.account_id'))
    except:
        pass
    
#Enable AD
def enable_ad(conn, setting):
    try:
        # Update settings database
        ad_enable = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(ad_enable, setting)
        conn.commit()
        cur.close()
    except:
        pass
def enable_fenlt_ad():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            enable_ad(conn, ('true', 'ad.enabled'))
    except:
        pass
    
#Disable AD
def disable_ad(conn, setting):
    try:
        # Update settings database
        ad_disable = ''' UPDATE settings
                  SET setting_value = ?
                  WHERE setting_id = ?'''

        cur = conn.cursor()
        cur.execute(ad_disable, setting)
        conn.commit()
        cur.close()
    except:
        pass
    
def disable_fenlt_ad():
    try:
        # Create database connection
        conn = create_conn(var.fenlt_settings_db)
        with conn:
            disable_ad(conn, ('false', 'ad.enabled'))
    except:
        pass
