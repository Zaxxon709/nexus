import xbmc
import xbmcplugin
import xbmcaddon
import xbmcvfs
import sys
import os
from .params import Params
from .menu import main_menu, add_players_menu, remove_players_menu, add_ind_players, remove_ind_players, chk_tmdbh
from .add_players import add_all, add_fast, add_free, add_top
from .remove_players import remove_all, remove_ind 

handle = int(sys.argv[1])

def router(paramstring):

    p = Params(paramstring)
    xbmc.log(str(p.get_params()),xbmc.LOGDEBUG)

    mode = p.get_mode()
    
    xbmcplugin.setContent(handle, 'files')

    if mode is None:
        main_menu()

    elif mode == 1:
        add_players_menu()

    elif mode == 2:
        remove_players_menu()

    elif mode == 3:
        if not xbmcvfs.exists(chk_tmdbh):
            add_players_menu()
        else:
            add_ind_players()

    elif mode == 4:
        add_all()

    elif mode == 5:
        add_fast()

    elif mode == 6:
        add_free()
        
    elif mode == 7:
        add_top()

    elif mode == 8:
        if not xbmcvfs.exists(chk_tmdbh):
            remove_players_menu()
        else:
            remove_ind_players()
        
    elif mode == 9:
        remove_all()

#Add Individual Players

    elif mode == 20:
        from resources.lib.modules import add_players
        add_players.add_ind.seren()
    elif mode == 22:
        from resources.lib.modules import add_players
        add_players.add_ind.fen()
    elif mode == 24:
        from resources.lib.modules import add_players
        add_players.add_ind.ezra()
    elif mode == 26:
        from resources.lib.modules import add_players
        add_players.add_ind.coalition()
    elif mode == 28:
        from resources.lib.modules import add_players
        add_players.add_ind.pov()
    elif mode == 30:
        from resources.lib.modules import add_players
        add_players.add_ind.umbrella()
    elif mode == 32:
        from resources.lib.modules import add_players
        add_players.add_ind.dradis()
    elif mode == 34:
        from resources.lib.modules import add_players
        add_players.add_ind.taz19()
    elif mode == 36:
        from resources.lib.modules import add_players
        add_players.add_ind.shadow()
    elif mode == 38:
        from resources.lib.modules import add_players
        add_players.add_ind.ghost()
    elif mode == 40:
        from resources.lib.modules import add_players
        add_players.add_ind.base19()      
    elif mode == 42:
        from resources.lib.modules import add_players
        add_players.add_ind.unleashed()
    elif mode == 44:
        from resources.lib.modules import add_players
        add_players.add_ind.chains()
    elif mode == 46:
        from resources.lib.modules import add_players
        add_players.add_ind.magicdragon()
    elif mode == 48:
        from resources.lib.modules import add_players
        add_players.add_ind.asgard()
    elif mode == 50:
        from resources.lib.modules import add_players
        add_players.add_ind.patriot()
    elif mode == 52:
        from resources.lib.modules import add_players
        add_players.add_ind.black_l()
    elif mode == 54:
        from resources.lib.modules import add_players
        add_players.add_ind.metv19()
    elif mode == 56:
        from resources.lib.modules import add_players
        add_players.add_ind.aliunde()        
    elif mode == 58:
        from resources.lib.modules import add_players
        add_players.add_ind.homelander()
    elif mode == 60:
        from resources.lib.modules import add_players
        add_players.add_ind.thelab()
    elif mode == 62:
        from resources.lib.modules import add_players
        add_players.add_ind.quicksilver()
    elif mode == 64:
        from resources.lib.modules import add_players
        add_players.add_ind.genocide()
    elif mode == 66:
        from resources.lib.modules import add_players
        add_players.add_ind.absolution()        
    elif mode == 68:
        from resources.lib.modules import add_players
        add_players.add_ind.shazam()
    elif mode == 70:
        from resources.lib.modules import add_players
        add_players.add_ind.thecrew()
    elif mode == 72:
        from resources.lib.modules import add_players
        add_players.add_ind.nightwing()
    elif mode == 74:
        from resources.lib.modules import add_players
        add_players.add_ind.alvin()
    elif mode == 76:
        from resources.lib.modules import add_players
        add_players.add_ind.moria()
    elif mode == 78:
        from resources.lib.modules import add_players
        add_players.add_ind.nine()
    elif mode == 80:
        from resources.lib.modules import add_players
        add_players.add_ind.scrubs()
    elif mode == 82:
        from resources.lib.modules import add_players
        add_players.add_ind.thelabjr()
    elif mode == 84:
        from resources.lib.modules import add_players
        add_players.add_ind.imdb()

#Remove Individual Players

    elif mode == 100:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.seren()
    elif mode == 102:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.fen() 
    elif mode == 104:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.ezra()
    elif mode == 106:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.coalition()
    elif mode == 108:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.pov()
    elif mode == 110:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.umbrella()
    elif mode == 112:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.dradis()
    elif mode == 114:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.taz19()
    elif mode == 116:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.shadow()
    elif mode == 118:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.ghost()
    elif mode == 120:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.base19()      
    elif mode == 122:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.unleashed()
    elif mode == 124:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.chains()
    elif mode == 126:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.magicdragon()
    elif mode == 128:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.asgard()
    elif mode == 130:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.patriot()
    elif mode == 132:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.black_l()
    elif mode == 134:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.metv19()
    elif mode == 136:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.aliunde()       
    elif mode == 138:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.homelander()
    elif mode == 140:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.thelab()
    elif mode == 142:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.quicksilver()
    elif mode == 144:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.genocide()
    elif mode == 146:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.absolution()       
    elif mode == 148:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.shazam()
    elif mode == 150:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.thecrew()
    elif mode == 152:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.nightwing()
    elif mode == 154:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.alvin()
    elif mode == 156:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.moria()
    elif mode == 158:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.nine()
    elif mode == 160:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.scrubs()
    elif mode == 162:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.thelabjr()
    elif mode == 164:
        from resources.lib.modules import remove_players
        remove_players.remove_ind.imdb()

    xbmcplugin.endOfDirectory(handle)
