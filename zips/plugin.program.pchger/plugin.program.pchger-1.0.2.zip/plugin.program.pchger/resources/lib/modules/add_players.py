import os
import shutil
import subprocess
import xbmcgui
import xbmcvfs
import xbmc, xbmcaddon
from pathlib import Path

src_all = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/all_players/')
src_fast = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/fast_players/')
src_free = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/free_players/')
src_top = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/top_players/')
dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/')
        
def add_all():
        try:
                files_dst = os.listdir(dst)
                files_src = os.listdir(src_all)
                for file in files_dst:
                        file_path = os.path.join(dst, file)
                        if os.path.isfile(file_path):
                                os.remove(file_path)
                for fname in files_src:
                        shutil.copy2(os.path.join(src_all,fname), dst)
                        xbmcgui.Dialog().notification('TMDbH', 'All Players Added!',xbmcgui.NOTIFICATION_INFO, 1000)   
        except:
                xbmc.log("Player Changer - Error occurred while adding All Players.", xbmc.LOGINFO)


def add_fast():
        try:
                files_dst = os.listdir(dst)
                files_src = os.listdir(src_fast)
                for file in files_dst:
                        file_path = os.path.join(dst, file)
                        if os.path.isfile(file_path):
                                os.remove(file_path)
                for fname in files_src:
                        shutil.copy2(os.path.join(src_fast,fname), dst)
                        xbmcgui.Dialog().notification('TMDbH', 'Fast Players Added!',xbmcgui.NOTIFICATION_INFO, 1000)
        except:
                xbmc.log("Player Changer - Error occurred while adding Fast Players.", xbmc.LOGINFO)

def add_free():
        try:
                files_dst = os.listdir(dst)
                files_src = os.listdir(src_free)
                for file in files_dst:
                        file_path = os.path.join(dst, file)
                        if os.path.isfile(file_path):
                                os.remove(file_path)
                for fname in files_src:
                        shutil.copy2(os.path.join(src_free,fname), dst)
                        xbmcgui.Dialog().notification('TMDbH', 'Free Players Added!',xbmcgui.NOTIFICATION_INFO, 1000)
        except:
                xbmc.log("Player Changer - Error occurred while adding Free Players.", xbmc.LOGINFO)

def add_top():
        try:
                files_dst = os.listdir(dst)
                files_src = os.listdir(src_top)
                for file in files_dst:
                        file_path = os.path.join(dst, file)
                        if os.path.isfile(file_path):
                                os.remove(file_path)
                for fname in files_src:
                        shutil.copy2(os.path.join(src_top,fname), dst)
                        xbmcgui.Dialog().notification('TMDbH', 'Top Players Added!',xbmcgui.NOTIFICATION_INFO, 1000)
        except:
                xbmc.log("Player Changer - Error occurred while adding Top Players.", xbmc.LOGINFO)
                
class add_ind:
        def seren():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/seren.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/seren.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def fen():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/fen.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/fen.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def ezra():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/ezra.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/ezra.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def coalition():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/coalition.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/coalition.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def pov():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/pov.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/pov.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def umbrella():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/umbrella.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/umbrella.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def dradis():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/dradis.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/dradis.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def taz19():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/taz19.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/taz19.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def shadow():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/shadow.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/shadow.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def ghost():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/ghost.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/ghost.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def base19():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/base19.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/base19.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def unleashed():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/unleashed.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/unleashed.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def chains():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/chains.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/chains.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def magicdragon():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/magicdragon.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/magicdragon.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)   
                
        def asgard():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/asgard.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/asgard.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def patriot():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/patriot.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/patriot.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def black_l():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/black_l.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/black_l.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def metv19():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/metv19.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/metv19.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def aliunde():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/aliunde.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/aliunde.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def homelander():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/homelander.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/homelander.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def thelab():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/thelab.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/thelab.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def quicksilver():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/quicksilver.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/quicksilver.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def genocide():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/genocide.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/genocide.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def absolution():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/absolution.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/absolution.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def shazam():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/shazam.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/shazam.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def thecrew():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/thecrew.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/thecrew.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def nightwing():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/nightwing.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/nightwing.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def alvin():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/alvin.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/alvin.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def moria():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/moria.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/moria.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def nine():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/nine.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/nine.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def scrubs():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/scrubs.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/scrubs.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)

        def thelabjr():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/thelabjr.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/thelabjr.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def imdb():
                src = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/players/imdb.json')
                dst = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/imdb.json')
                
                shutil.copyfile(src, dst)
                xbmcgui.Dialog().notification('TMDbH', 'Player Added!',xbmcgui.NOTIFICATION_INFO, 1000)
