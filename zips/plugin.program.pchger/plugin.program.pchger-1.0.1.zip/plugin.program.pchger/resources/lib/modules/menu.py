import os
import sys
import json
import xbmc
import xbmcplugin
import xbmcvfs
import xbmcgui
from .utils import add_dir

icon_path = xbmcvfs.translatePath('special://home/addons/plugin.program.pchger/icons/')
player_path = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/')
addon_path = xbmcvfs.translatePath('special://home/addons/')

#Icon Paths
addon_fanart = icon_path + 'fanart.jpg'
addon_icon = icon_path + 'pchger.png'
choose_icon = icon_path + 'choose.png'
default_icon = icon_path + 'default.png'
add_icon = icon_path + 'add.png'
remove_icon = icon_path + 'remove.png'
free_icon = icon_path + 'free.png'
seven_icon = icon_path + '709.png'
fast_icon = icon_path + 'fast.png'
seren_icon = icon_path + 'seren.png'
fen_icon = icon_path + 'fen.png'
ezra_icon = icon_path + 'ezra.png'
coalition_icon = icon_path + 'coalition.png'
pov_icon = icon_path + 'pov.png'
umbrella_icon = icon_path + 'umbrella.png'
dradis_icon = icon_path + 'dradis.png'
taz19_icon = icon_path + 'taz19.png'
shadow_icon = icon_path + 'shadow.png'
ghost_icon = icon_path + 'ghost.png'
base19_icon = icon_path + 'base19.png'
unleashed_icon = icon_path + 'unleashed.png'
chains_icon = icon_path + 'chains.png'
magicdragon_icon = icon_path + 'magicdragon.png'
asgard_icon = icon_path + 'asgard.png'
patriot_icon = icon_path + 'patriot.png'
black_l_icon = icon_path + 'black_l.png'
metv_icon = icon_path + 'metv.png'
aliunde_icon = icon_path + 'aliunde.png'
homelander_icon = icon_path + 'homelander.png'
thelab_icon = icon_path + 'thelab.png'
quicksilver_icon = icon_path + 'quick.png'
genocide_icon = icon_path + 'genocide.png'
absolution_icon = icon_path + 'absolution.png'
shazam_icon = icon_path + 'shazam.png'
thecrew_icon = icon_path + 'thecrew.png'
nightwing_icon = icon_path + 'nightwing.png'
alvin_icon = icon_path + 'alvin.png'
moria_icon = icon_path + 'moria.png'
nine_icon = icon_path + 'nine.png'
scrubs_icon = icon_path + 'scrubs.png'
thelabjr_icon = icon_path + 'thelabjr.png'
imdb_icon = icon_path + 'imdb.png'

#Player Paths
seren = player_path + 'seren.json'
fen = player_path + 'fen.json'
ezra = player_path + 'ezra.json'
coalition = player_path + 'coalition.json'
pov = player_path + 'pov.json'
umbrella = player_path + 'umbrella.json'
dradis = player_path + 'dradis.json'
taz19 = player_path + 'taz19.json'
shadow = player_path + 'shadow.json'
ghost = player_path + 'ghost.json'
base19 = player_path + 'base19.json'
unleashed = player_path + 'unleashed.json'
chains = player_path + 'thechains.json'
magicdragon = player_path + 'magicdragon.json'
asgard = player_path + 'asgard.json'
patriot = player_path + 'patriot.json'
black_l = player_path + 'blacklightning.json'
metv19 = player_path + 'metv19.json'
aliunde = player_path + 'aliunde.json'
homelander = player_path + 'homelander.json'
thelab = player_path + 'thelab.json'
quicksilver = player_path + 'quicksilver.json'
genocide = player_path + 'genocide.json'
absolution = player_path + 'absolution.json'
shazam = player_path + 'shazam.json'
thecrew = player_path + 'thecrew.json'
nightwing = player_path + 'nightwing.json'
alvin = player_path + 'alvin.json'
moria = player_path + 'moria.json'
nine = player_path + '9lives.json'
scrubs = player_path + 'scrubsv2.json'
thelabjr = player_path + 'thelabjr.json'
imdb = player_path + 'imdbtrailers.json'

#Add-on Paths
chk_seren = addon_path + 'plugin.video.seren/'
chk_fen = addon_path + 'plugin.video.fen/'
chk_ezra = addon_path + 'plugin.video.ezra/'
chk_coal = addon_path + 'plugin.video.coalition/'
chk_pov = addon_path + 'plugin.video.pov/'
chk_umb = addon_path + 'plugin.video.umbrella/'
chk_dradis = addon_path + 'plugin.video.dradis/'
chk_taz = addon_path + 'plugin.video.taz19/'
chk_shadow = addon_path + 'plugin.video.shadow/'
chk_ghost = addon_path + 'plugin.video.ghost/'
chk_base = addon_path + 'plugin.video.base19/'
chk_unleashed = addon_path + 'plugin.video.unleashed/'
chk_chains = addon_path + 'plugin.video.thechains/'
chk_twisted = addon_path + 'plugin.video.twisted/'
chk_md = addon_path + 'plugin.video.magicdragon/'
chk_asgard = addon_path + 'plugin.video.asgard/'
chk_patriot = addon_path + 'plugin.video.patriot/'
chk_blackl = addon_path + 'plugin.video.blacklightning/'
chk_metv = addon_path + 'plugin.video.metv19/'
chk_aliunde = addon_path + 'plugin.video.aliundek19/'
chk_home = addon_path + 'plugin.video.homelander/'
chk_lab = addon_path + 'plugin.video.thelab/'
chk_quick = addon_path + 'plugin.video.quicksilver/'
chk_genocide = addon_path + 'plugin.video.chainsgenocide/'
chk_absol = addon_path + 'plugin.video.absolution/'
chk_shazam = addon_path + 'plugin.video.shazam/'
chk_crew = addon_path + 'plugin.video.thecrew/'
chk_night = addon_path + 'plugin.video.nightwing/'
chk_alvin = addon_path + 'plugin.video.alvin/'
chk_moria = addon_path + 'plugin.video.moria/'
chk_nine = addon_path + 'plugin.video.nine/'
chk_scrubs = addon_path + 'plugin.video.scrubsv2/'
chk_labjr = addon_path + 'plugin.video.thelabjr/'
chk_imdb = addon_path + 'plugin.video.imdbtrailers/'

src = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/')
chk_empty = os.listdir(src)

not_installed = 'Add-on Not Installed!'
COLOR = f'[COLOR red]{not_installed}[/COLOR]'

handle = int(sys.argv[1])

def main_menu():
    xbmcplugin.setPluginCategory(handle, 'Main Menu')
    
    add_dir('Add Players','',1,add_icon,addon_fanart,isFolder=True)
    add_dir('Remove Players','',2,remove_icon,addon_fanart,isFolder=True)


def add_players_menu():
    xbmcplugin.setPluginCategory(handle, 'Add Players')

    add_dir('Choose Your Players','',3,choose_icon,addon_fanart,isFolder=True)
    add_dir('Add All Players','',4,add_icon,addon_fanart,isFolder=False)
    add_dir('Add Fast Players','',5,fast_icon,addon_fanart,isFolder=False)
    add_dir('Add Free Players','',6,free_icon,addon_fanart,isFolder=False)
    add_dir("Add 7o9's Top Picks",'',7,seven_icon,addon_fanart,isFolder=False)


def remove_players_menu():
    xbmcplugin.setPluginCategory(handle, 'Remove Players')

    add_dir('Choose Players to Remove','',8,choose_icon,addon_fanart,isFolder=True)
    add_dir('Remove All Players','',9,remove_icon,addon_fanart,isFolder=False)

    
def add_ind_players():
    xbmcplugin.setPluginCategory(handle, 'Add Players')

    if xbmcvfs.exists(seren) and xbmcvfs.exists(chk_seren):
        pass
    else:
        if not xbmcvfs.exists(seren) and xbmcvfs.exists(chk_seren):
            add_dir('Add Seren Player','',20,seren_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Seren Player - {COLOR}','',20,seren_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(fen) and xbmcvfs.exists(chk_fen):
        pass
    else:
        if not xbmcvfs.exists(fen) and xbmcvfs.exists(chk_fen):
            add_dir('Add Fen Player','',22,fen_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Fen Player - {COLOR}','',22,fen_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(ezra) and xbmcvfs.exists(chk_ezra):
        pass
    else:
        if not xbmcvfs.exists(ezra) and xbmcvfs.exists(chk_ezra):
            add_dir('Add Ezra Player','',24,ezra_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Ezra Player - {COLOR}','',24,ezra_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(coalition) and xbmcvfs.exists(chk_coal):
        pass
    else:
        if not xbmcvfs.exists(coalition) and xbmcvfs.exists(chk_coal):
            add_dir('Add Coalition Player','',26,coalition_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Coalition Player - {COLOR}','',26,coalition_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(pov) and xbmcvfs.exists(chk_pov):
        pass
    else:
        if not xbmcvfs.exists(pov) and xbmcvfs.exists(chk_pov):
            add_dir('Add POV Player','',28,pov_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add POV Player - {COLOR}','',28,pov_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(umbrella) and xbmcvfs.exists(chk_umb):
        pass
    else:
        if not xbmcvfs.exists(umbrella) and xbmcvfs.exists(chk_umb):
            add_dir('Add Umbrella Player','',30,umbrella_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Umbrella Player - {COLOR}','',30,umbrella_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(dradis) and xbmcvfs.exists(chk_dradis):
        pass
    else:
        if not xbmcvfs.exists(dradis) and xbmcvfs.exists(chk_dradis):
            add_dir('Add Dradis Player','',32,dradis_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Dradis Player - {COLOR}','',32,dradis_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(taz19) and xbmcvfs.exists(chk_taz):
        pass
    else:
        if not xbmcvfs.exists(taz19) and xbmcvfs.exists(chk_taz):
            add_dir('Add Taz19 Player','',34,taz19_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Taz19 Player - {COLOR}','',34,taz19_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(shadow) and xbmcvfs.exists(chk_shadow):
        pass
    else:
        if not xbmcvfs.exists(shadow) and xbmcvfs.exists(chk_shadow):
            add_dir('Add Shadow Player','',36,shadow_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Shadow Player - {COLOR}','',36,shadow_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(ghost) and xbmcvfs.exists(chk_ghost):
        pass
    else:
        if not xbmcvfs.exists(ghost) and xbmcvfs.exists(chk_ghost):
            add_dir('Add Ghost Player','',38,ghost_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Ghost Player - {COLOR}','',38,ghost_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(base19) and xbmcvfs.exists(chk_base):
        pass
    else:
        if not xbmcvfs.exists(base19) and xbmcvfs.exists(chk_base):
            add_dir('Add Base 19 Player','',40,base19_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Base 19 Player - {COLOR}','',40,base19_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(unleashed) and xbmcvfs.exists(chk_unleashed):
        pass
    else:
        if not xbmcvfs.exists(unleashed) and xbmcvfs.exists(chk_unleashed):
            add_dir('Add Unleashed Player','',42,unleashed_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Unleased Player - {COLOR}','',42,unleashed_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(chains) and xbmcvfs.exists(chk_chains):
        pass
    else:
        if not xbmcvfs.exists(chains) and xbmcvfs.exists(chk_chains):
            add_dir('Add Chain Reaction Player','',44,chains_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Chain Reaction Player - {COLOR}','',44,chains_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(magicdragon) and xbmcvfs.exists(chk_md):
        pass
    else:
        if not xbmcvfs.exists(magicdragon) and xbmcvfs.exists(chk_md):
            add_dir('Add Magic Dragon Player','',46,magicdragon_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Magic Dragon Player - {COLOR}','',46,magicdragon_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(asgard) and xbmcvfs.exists(chk_asgard):
        pass
    else:
        if not xbmcvfs.exists(asgard) and xbmcvfs.exists(chk_asgard):
            add_dir('Add Asgard Player','',48,asgard_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Asgard Player - {COLOR}','',48,asgard_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(patriot) and xbmcvfs.exists(chk_patriot):
        pass
    else:
        if not xbmcvfs.exists(patriot) and xbmcvfs.exists(chk_patriot):
            add_dir('Add Patriot Player','',50,patriot_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Patriot Player - {COLOR}','',50,patriot_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(black_l) and xbmcvfs.exists(chk_blackl):
        pass
    else:
        if not xbmcvfs.exists(black_l) and xbmcvfs.exists(chk_blackl):
            add_dir('Add Fen Player','',52,black_l_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Fen Player - {COLOR}','',52,black_l_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(metv19) and xbmcvfs.exists(chk_metv):
        pass
    else:
        if not xbmcvfs.exists(metv19) and xbmcvfs.exists(chk_metv):
            add_dir('Add M.E.T.V Player','',54,metv_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add M.E.T.V Player - {COLOR}','',54,metv_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(aliunde) and xbmcvfs.exists(chk_aliunde):
        pass
    else:
        if not xbmcvfs.exists(aliunde) and xbmcvfs.exists(chk_aliunde):
            add_dir('Add Aliunde Player','',56,aliunde_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Aliunde Player - {COLOR}','',56,aliunde_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(homelander) and xbmcvfs.exists(chk_home):
        pass
    else:
        if not xbmcvfs.exists(homelander) and xbmcvfs.exists(chk_home):
            add_dir('Add Homelander Player','',58,homelander_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Homelander Player - {COLOR}','',58,homelander_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(thelab) and xbmcvfs.exists(chk_lab):
        pass
    else:
        if not xbmcvfs.exists(thelab) and xbmcvfs.exists(chk_lab):
            add_dir('Add TheLab Player','',60,thelab_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add TheLab Player - {COLOR}','',60,thelab_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(quicksilver) and xbmcvfs.exists(chk_quick):
        pass
    else:
        if not xbmcvfs.exists(quicksilver) and xbmcvfs.exists(chk_quick):
            add_dir('Add Quicksilver Player','',62,quicksilver_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Quicksilver Player - {COLOR}','',62,quicksilver_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(genocide) and xbmcvfs.exists(chk_genocide):
        pass
    else:
        if not xbmcvfs.exists(genocide) and xbmcvfs.exists(chk_genocide):
            add_dir('Add Chains Genocide Player','',64,genocide_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Chains Genocide Player - {COLOR}','',64,genocide_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(absolution) and xbmcvfs.exists(chk_absol):
        pass
    else:
        if not xbmcvfs.exists(absolution) and xbmcvfs.exists(chk_absol):
            add_dir('Add Absolution Player','',66,absolution_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Absolution Player - {COLOR}','',66,absolution_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(shazam) and xbmcvfs.exists(chk_shazam):
        pass
    else:
        if not xbmcvfs.exists(shazam) and xbmcvfs.exists(chk_shazam):
            add_dir('Add Shazam Player','',68,shazam_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Shazam Player - {COLOR}','',68,shazam_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(thecrew) and xbmcvfs.exists(chk_crew):
        pass
    else:
        if not xbmcvfs.exists(thecrew) and xbmcvfs.exists(chk_crew):
            add_dir('Add The Crew Player','',70,thecrew_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add The Crew Player - {COLOR}','',70,thecrew_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(nightwing) and xbmcvfs.exists(chk_night):
        pass
    else:
        if not xbmcvfs.exists(nightwing) and xbmcvfs.exists(chk_night):
            add_dir('Add Nightwing Player','',72,nightwing_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Nightwing Player - {COLOR}','',72,nightwing_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(alvin) and xbmcvfs.exists(chk_alvin):
        pass
    else:
        if not xbmcvfs.exists(alvin) and xbmcvfs.exists(chk_alvin):
            add_dir('Add Alvin Player','',74,alvin_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Alvin Player - {COLOR}','',74,alvin_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(moria) and xbmcvfs.exists(chk_moria):
        pass
    else:
        if not xbmcvfs.exists(moria) and xbmcvfs.exists(chk_moria):
            add_dir('Add Moria Player','',76,moria_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Moria Player - {COLOR}','',76,moria_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(nine) and xbmcvfs.exists(chk_nine):
        pass
    else:
        if not xbmcvfs.exists(nine) and xbmcvfs.exists(chk_nine):
            add_dir('Add 9 Lives Player','',78,nine_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add 9 Lives Player - {COLOR}','',78,nine_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(scrubs) and xbmcvfs.exists(chk_scrubs):
        pass
    else:
        if not xbmcvfs.exists(scrubs) and xbmcvfs.exists(chk_scrubs):
            add_dir('Add Scrubs V2 Player','',80,scrubs_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add Scrubs V2 Player - {COLOR}','',80,scrubs_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(thelabjr) and xbmcvfs.exists(chk_labjr):
        pass
    else:
        if not xbmcvfs.exists(thelabjr) and xbmcvfs.exists(chk_labjr):
            add_dir('Add TheLabjr Player','',82,thelabjr_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add TheLabjr Player - {COLOR}','',82,thelabjr_icon,addon_fanart,isFolder=False)
            
    if xbmcvfs.exists(imdb) and xbmcvfs.exists(chk_imdb):
        pass
    else:
        if not xbmcvfs.exists(imdb) and xbmcvfs.exists(chk_imdb):
            add_dir('Add IMDb Trailers Player','',84,imdb_icon,addon_fanart,isFolder=False)
        else:
            add_dir(f'Add IMDd Trailers Player - {COLOR}','',84,imdb_icon,addon_fanart,isFolder=False)
    

def remove_ind_players():
    xbmcplugin.setPluginCategory(handle, 'Remove Players')

    if len(chk_empty) == 0:
        xbmcgui.Dialog().notification('TMDbH', 'No Players to Remove!',xbmcgui.NOTIFICATION_INFO, 1000)
        xbmc.executebuiltin('Action(back)')
    else:
        if xbmcvfs.exists(seren):
            add_dir('Remove Seren Player','',100,seren_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(fen):
            add_dir('Remove Fen Player','',102,fen_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(ezra):
            add_dir('Remove Ezra Player','',104,ezra_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(coalition):
            add_dir('Remove Coalition Player','',106,coalition_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(pov):
            add_dir('Remove POV Player','',108,pov_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(umbrella):
            add_dir('Remove Umbrella Player','',110,umbrella_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(dradis):
            add_dir('Remove Dradis Player','',112,dradis_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(taz19):
            add_dir('Remove Taz19 Player','',114,taz19_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(shadow):
            add_dir('Remove Shadow Player','',116,shadow_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(ghost):
            add_dir('Remove Ghost Player','',118,ghost_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(base19):
            add_dir('Remove Base19 Player','',120,base19_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(unleashed):
            add_dir('Remove Unleashed Player','',122,unleashed_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(chains):
            add_dir('Remove Chain Reaction Player','',124,chains_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(magicdragon):
            add_dir('Remove Magic Dragon Player','',126,magicdragon_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(asgard):
            add_dir('Remove Asgard Player','',128,asgard_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(patriot):
            add_dir('Remove Patriot Player','',130,patriot_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(black_l):
            add_dir('Remove Black Lightning Player','',132,black_l_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(metv19):
            add_dir('Remove M.E.T.V Player','',134,metv_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(aliunde):
            add_dir('Remove Aliunde Player','',136,aliunde_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(homelander):
            add_dir('Remove Homelander Player','',138,homelander_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(thelab):
            add_dir('Remove TheLab Player','',140,thelab_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(quicksilver):
            add_dir('Remove Quicksilver Player','',142,quicksilver_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(genocide):
            add_dir('Remove Chains Genocide Player','',144,genocide_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(absolution):
            add_dir('Remove Absolution Player','',146,absolution_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(shazam):
            add_dir('Remove Shazam Player','',148,shazam_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(thecrew):
            add_dir('Remove The Crew Player','',150,thecrew_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(nightwing):
            add_dir('Remove Nightwing Player','',152,nightwing_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(alvin):
            add_dir('Remove Alvin Player','',154,alvin_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(moria):
            add_dir('Remove Moria Player','',156,moria_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(nine):
            add_dir('Remove Nine Lives Player','',158,nine_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(scrubs):
            add_dir('Remove Scrubs V2 Player','',160,scrubs_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(thelabjr):
            add_dir('Remove TheLabjr Player','',162,thelabjr_icon,addon_fanart,isFolder=False)
        else:
            pass
        
        if xbmcvfs.exists(imdb):
            add_dir('Remove IMDb Trailers Player','',164,imdb_icon,addon_fanart,isFolder=False)
        else:
            pass
