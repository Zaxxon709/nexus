import os
import shutil
import subprocess
import xbmcgui
import xbmcvfs
import xbmc, xbmcaddon

src = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/')
chk_empty = os.listdir(src)

def remove_all():
        try:
                if len(chk_empty) == 0:
                        xbmcgui.Dialog().notification('TMDbH', 'No Players to Remove!',xbmcgui.NOTIFICATION_INFO, 1000)
                else:
                        files_src = os.listdir(src)
                        for file in files_src:
                                file_path = os.path.join(src, file)
                                if os.path.isfile(file_path):
                                        os.remove(file_path)
                                        xbmcgui.Dialog().notification('TMDbH', 'All Players Removed!',xbmcgui.NOTIFICATION_INFO, 1000)         
        except:
                xbmc.log("Player Changer - Error occurred while removing All Players.", xbmc.LOGINFO)

                
class remove_ind:
        def seren():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/seren.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/seren.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
                        
        def fen():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/fen.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/fen.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def ezra():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/ezra.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/ezra.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def coalition():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/coalition.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/coalition.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def pov():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/pov.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/pov.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def umbrella():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/umbrella.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/umbrella.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def dradis():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/dradis.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/dradis.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def taz19():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/taz19.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/taz19.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def shadow():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/shadow.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/shadow.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def ghost():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/ghost.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/ghost.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def base19():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/base19.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/base19.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def unleashed():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/unleashed.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/unleashed.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def chains():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/chains.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/chains.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def magicdragon():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/magicdragon.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/magicdragon.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)   
                
        def asgard():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/asgard.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/asgard.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def patriot():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/patriot.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/patriot.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def black_l():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/black_l.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/black_l.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def metv19():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/metv19.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/metv19.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def aliunde():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/aliunde.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/aliunde.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def homelander():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/homelander.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/homelander.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def thelab():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/thelabjson')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/thelab.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def quicksilver():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/quicksilver.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/quicksilver.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def genocide():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/genocide.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/genocide.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def absolution():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/absolution.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/absolution.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def shazam():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/shazam.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/shazam.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def thecrew():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/thecrew.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/thecrew.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def nightwing():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/nightwing.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/nightwing.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def alvin():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/alvin.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/alvin.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def moria():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/moria.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/moria.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def nine():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/nine.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/nine.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def scrubs():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/scrubs.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/scrubs.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)

        def thelabjr():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/thelabjr.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/thelabjr.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
                
        def imdb():
                player_file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/imdb.json')
               
                if xbmcvfs.exists(player_file):
                        file = xbmcvfs.translatePath('special://userdata/addon_data/plugin.video.themoviedb.helper/reconfigured_players/imdb.json')
                        os.remove(file)
                        xbmcgui.Dialog().notification('TMDbH', 'Player Removed!',xbmcgui.NOTIFICATION_INFO, 1000)
