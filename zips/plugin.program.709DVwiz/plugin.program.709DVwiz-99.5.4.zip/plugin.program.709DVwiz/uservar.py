import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://dr-venture.com/709/WizardDV/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://dr-venture.com/709/WizardDV/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
