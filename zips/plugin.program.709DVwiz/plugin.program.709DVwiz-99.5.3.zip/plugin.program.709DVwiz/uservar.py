import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://dr-venture.com/709/WizardDV/Omega/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://dr-venture.com/709/WizardDV/Omega/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
